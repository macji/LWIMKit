//
//  DTMediaId.h
//  DTMediaId
//
//  Created by anlanchen on 14-8-7.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(int16_t, DTMediaType)
{
    IMAGE_JPG   = 0,
    IMAGE_GIF,
    IMAGE_PNG,
    IMAGE_BMP,
    AUDIO_AMR,
    AUDIO_MP3,
    VIDEO_MP4,
    AUDIO_WAV,
    NORMAL_FILE,
    OFFICE_DOC,
    OFFICE_DOCX,
    OFFICE_XLS,
    OFFICE_XLSX,
    OFFICE_PPT,
    OFFICE_PPTX,
    NORMAL_ZIP,
    NORMAL_PDF,
    NORMAL_RAR,
    NORMAL_PSD,
    NORMAL_AI,
    NORMAL_TXT,
    VIDEO_AVI,
    VIDEO_RMVB,
    VIDEO_RM,
    VIDEO_MPG,
    VIDEO_WMV,
    VIDEO_MKV,
    VIDEO_VOB,
    NORMAL_TFSPRIVATE,
    IMAGE_WEBP
};

@interface DTMediaId : NSObject

@property (nonatomic, assign) DTMediaType type;
@property (nonatomic, assign) int64_t sequence;
@property (nonatomic, assign) BOOL burn;
@property (nonatomic, assign) int height;
@property (nonatomic, assign) int width;

- (NSString *)getTypeStr;

@end
