//
//  OpenConnection.h
//  LWSQLiteHookExample
//
//  Created by Lings on 15/8/5.
//  Copyright (c) 2015年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@class OpenConnection;

@protocol OpenConnectionDelegate <NSObject>

@optional

- (void)connectionDidOpen:(OpenConnection *)conn;
- (void)connectionDidClose:(OpenConnection *)conn;
- (void)connectionDidRemoveFileInPath:(NSString *)path;

- (void)connectionWillRekeyInPath:(NSString *)path;
- (void)connectionDidRekeyInPath:(NSString *)path;

@end


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@interface OpenConnection : NSObject

@property (nonatomic, assign, readonly) sqlite3 *sqlite;

@property (nonatomic, weak) id<OpenConnectionDelegate> delegate;


/**
 *  初始化一个db connection
 *
 *  @param path       db绝对路径，不能为nil
 *  @param delegate   delegate
 *
 *  @return 打开成功则返回实例，否则返回nil
 */
- (instancetype)initWithPath:(NSString *)path
                    readOnly:(BOOL)readOnly
                    delegate:(id<OpenConnectionDelegate>)delegate;


#ifdef SQLITE_HAS_CODEC

/**
 *  初始化一个db connection
 *
 *  @param path       db绝对路径，不能为nil
 *  @param passphrase db密钥，不超过 16 Bytes，如果没加密则传nil
 *  @param delegate   delegate
 *
 *  @return 打开成功则返回实例，否则返回nil
 */
- (instancetype)initWithPath:(NSString *)path
                  passphrase:(NSString *)passphrase
                    readOnly:(BOOL)readOnly
                    delegate:(id<OpenConnectionDelegate>)delegate;

- (void)rekey:(NSString *)passphrase;

#endif


- (void)close;

- (BOOL)isBusy:(NSInteger *)runningCount;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#pragma mark - SQL Functions

// 同步返回

- (NSArray *)executeSql:(NSString *)sql;

- (NSArray *)executeSql:(NSString *)sql withParameters:(NSArray *)parameters;

- (NSArray *)executeSql:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass;


- (NSArray *)executeSqlV2:(NSString *)sql withParameters:(NSArray *)parameters rowChanged:(NSUInteger *)rowChanged;

- (NSArray *)executeSqlV2:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass rowChanged:(NSUInteger *)rowChanged;


// 异步返回

- (void)executeSql:(NSString *)sql done:(void (^)(NSArray *results))doneBlock;

- (void)executeSql:(NSString *)sql withParameters:(NSArray *)parameters done:(void (^)(NSArray *results))doneBlock;

- (void)executeSql:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass done:(void (^)(NSArray *results))doneBlock;


// 同步事务
- (void)inTransaction:(void (^)(BOOL *rollback))block;

// 异步事务
- (void)inTransaction:(void (^)(BOOL *rollback))block done:(void (^)(BOOL isFinish))doneBlock;


// 其他接口

- (NSUInteger)lastInsertRowId;

- (NSUInteger)rowChanges;



@end

