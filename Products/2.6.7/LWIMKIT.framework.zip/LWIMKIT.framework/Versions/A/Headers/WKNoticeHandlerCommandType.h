//
//  WKNoticeHandlerCommandType.h
//  Pods
//
//  Created by guodi.ggd on 7/13/15.
//
//

#ifndef Pods_WKNoticeHandlerCommandType_h
#define Pods_WKNoticeHandlerCommandType_h

#define WKNoticeHandlerInfoModelClassKey    @"WKNoticeSaveModelClassKey"
#define WKNoticeHandlerInfoCommandKey       @"WKNoticeSaveCommandType"

typedef NS_ENUM(NSInteger, WKReconnectNoticeHandlerCommandType)
{
    WKReconnectNoticeHandlerNone,
    WKReconnectNoticeHandlerUpdateConversation,
    WKReconnectNoticeHandlerUpdateMessageStatus,
    WKReconnectNoticeHandlerUpdateNoticeModel,
};

#endif
