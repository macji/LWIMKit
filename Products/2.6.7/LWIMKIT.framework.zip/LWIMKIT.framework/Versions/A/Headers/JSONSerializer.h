//
//  JSONSerializer.h
//  OCJSONKitExample
//
//  Created by zhiwen.mizw on 8/26/14.
//  Copyright (c) 2014 zhiwen.mizw. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONClassUtil.h"

// Filter define
typedef BOOL (^JSONClassFieldFilter)(id object, JSONClassField *classField);
typedef id (^JSONValueFilter)(id object, JSONClassField *classField, id value);

#define JSON_FIELD_TYPE_IDENTIFIER @"@Type"

typedef NS_ENUM(NSInteger, JSONSerializerFeature)
{
    JSON_DEFAULT_FEATURE = 0,
    JSON_WRITE_CLASS_NAME = 1 << 0,
    JSON_INCLUDE_READ_ONLY_FIELD = 1 << 1,
};

@class JSONSerializer;

/**
 *  JSON 序列化与反序列化定义
 */
@protocol JSONObjectSerializer<NSObject>

- (id)serializeObject:(JSONSerializer *)serializer object:(id)object;

- (id)deSerializeObject:(JSONSerializer *)serializer
              fieldName:(NSString *)fieldName
                   data:(id)data
               instance:(id)instance;

@end

@interface JSONSerializer : NSObject

@property (nonatomic, strong) JSONClassFieldFilter classFieldFilter;

@property (nonatomic, strong) JSONValueFilter valueFitler;

@property (nonatomic) JSONSerializerFeature features;

- (id)serializeObject:(id)object;

- (id)deSerializeObject:(id)instance data:(id)data;

- (id<JSONObjectSerializer>)getObjectSerializer:(id)object;

- (BOOL)isWriteClassName;

- (Class)findDataTypeClass:(id)dicsData;

@end
