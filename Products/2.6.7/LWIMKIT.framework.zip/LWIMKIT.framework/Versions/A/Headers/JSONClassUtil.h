//
//  JSONClassUtil.h
//  OCJSON
//
//  Created by zhiwen.mizw on 8/19/14.
//  Copyright (c) 2014 zhiwen.mizw. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONClassField.h"

#define LogClassInfo(classField)                                                                   \
// NSLog(@"INFO: ==ecode:%@ key:%@", classField.fieldType, classField.fieldName);

#define LogNotSupportedType(object, classField)                                                    \
//    NSLog(@"ERROR: toJSONString not supported type class=[%@] fieldName=[%@] fieldType=[%@]",      \
//          NSStringFromClass([object class]), classField.fieldName, classField.fieldType);

#define LogNotSupportedTransfer(classField)                                                        \
    NSLog(@"not supported Transfer of field:%@ type:%@ isstruct:%d", classField.fieldName,         \
          classField.fieldType, classField.isStructType);

@interface JSONClassUtil : NSObject

+ (instancetype)sharedInstance;

- (NSArray *)classFieldInfo:(Class)clazz;

- (NSArray *)classFieldInfoBySelf:(Class)clazz;

- (void)typeEncodingToClassName:(JSONClassField *)classField withType:(NSString *)fieldType;

@end