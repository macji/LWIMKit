//
//  LWDatabase.h
//  LWDatabase
//
//  Created by 香象 on 25/11/13.
//  Copyright (c) 2013 香象. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "OpenConnection.h"

#if OS_OBJECT_USE_OBJC
#undef SDDispatchQueueRelease
#undef SDDispatchQueueSetterSementics
#define SDDispatchQueueRelease(q)
#define SDDispatchQueueSetterSementics strong
#else
#undef SDDispatchQueueRelease
#undef SDDispatchQueueSetterSementics
#define SDDispatchQueueRelease(q) (dispatch_release(q))
#define SDDispatchQueueSetterSementics assign
#endif

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@class OpenDatabase;

@protocol OpenDatabaseDelegate<NSObject>

@optional

- (void)didRemoveDbFileInPath:(NSString *)databasePath;

- (void)willRekeyDatabaseInPath:(NSString *)databasePath;
- (void)didRekeyDatabaseInPath:(NSString *)databasePath;

@end


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@interface OpenDatabase : NSObject

@property (nonatomic, copy, readonly) NSString *pathToDatabase;

@property (nonatomic, copy) NSString *dbName; // 给数据库一个名字，以便后期从搜索引擎中取出数据后能通过dbname来找到相应的db对象

@property (nonatomic, weak) id<OpenDatabaseDelegate> delegate;



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
- (id)initWithPath:(NSString *)filePath;


- (id)initWithPath:(NSString *)filePath
          delegate:(id<OpenDatabaseDelegate>)delegate;

#ifdef SQLITE_HAS_CODEC

// passphrase 不超过 16 Bytes，如果没加密则传nil
- (id)initWithPath:(NSString *)filePath
        passphrase:(NSString *)passphrase
          delegate:(id<OpenDatabaseDelegate>)delegate;

// 重设密码 如果传nil，即不给db加密
- (void)rekey:(NSString *)passphrase;

#endif


- (void)close;

// Hook专用，请勿随意传递sqlite指针
- (sqlite3 *)sqliteForHook;

// Hook专用
- (OpenConnection *)connectionForHook;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#pragma mark - SQL Functions

// 同步返回

- (NSArray *)executeSql:(NSString *)sql;

- (NSArray *)executeSqlWithParameters:(NSString *)sql, ...;

- (NSArray *)executeSql:(NSString *)sql withParameters:(NSArray *)parameters;

- (NSArray *)executeSql:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass;


- (NSArray *)executeSqlV2:(NSString *)sql withParameters:(NSArray *)parameters rowChanged:(NSUInteger *)rowChanged;

- (NSArray *)executeSqlV2:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass rowChanged:(NSUInteger *)rowChanged;


// 异步返回

- (void)executeSql:(NSString *)sql done:(void (^)(NSArray *results))doneBlock;

- (void)executeSql:(NSString *)sql withParameters:(NSArray *)parameters done:(void (^)(NSArray *results))doneBlock;

- (void)executeSql:(NSString *)sql withParameters:(NSArray *)parameters withClassForRow:(Class)rowClass done:(void (^)(NSArray *results))doneBlock;


// 同步事务
- (void)inTransaction:(void (^)(OpenDatabase *db, BOOL *rollback))block;

// 异步事务
- (void)inTransaction:(void (^)(OpenDatabase *db, BOOL *rollback))block done:(void (^)(BOOL isFinish))doneBlock;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#pragma mark - Table Functions

- (NSUInteger)lastInsertRowId;

- (NSUInteger)rowChanges;

- (NSArray *)tableNames;

- (NSArray *)columnsFromCacheForTableName:(NSString *)tableName;

- (void)removeColumnsCacheForTableName:(NSString *)tableName;

- (void)cleanColumnsCache;


@end
