//
//  WKBizNotice.h
//  LWIMKitExample
//
//  Created by 香象 on 18/12/14.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WKBizNotice : NSObject

@property(nonatomic, strong) NSNumber*     type ;

@property(nonatomic, strong) NSData*     content ;


@end
