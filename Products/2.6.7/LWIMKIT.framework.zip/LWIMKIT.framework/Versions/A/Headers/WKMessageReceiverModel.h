//
//  WKMessageReceiverModel.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-10-22.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, WKMessageReceiverStatus) {
    WKMessageUndeliveredStatus = 0,//未送达
    WKMessageDeliveredUnreadStatus = 1,//已送达未读
    WKMessageDeliveredReadStatus = 2,//已读
};

@protocol WKMessageReceiverModel <NSObject>

/**
 *  消息ID
 */
@property (nonatomic, readonly) int64_t messageId;

/**
 *  消息所在会话ID
 */
@property (nonatomic, copy, readonly) NSString *conversationId;

/**
 *  消息接受人id，就是openId
 */
@property (nonatomic, readonly) int64_t receiverId;

/**
 *  消息接受人的版本
 */
@property (nonatomic, readonly) long receiverTag;


/**
 *  接受者对于该消息的状态（0：未送达 1：已送达未读 2：已读）
 */
@property (nonatomic) WKMessageReceiverStatus messageStatus;

/**
 *  接受者是否已读该消息
 */
-(bool)hasRead;


@end
