//
//  WKBizXpnPushModel.h
//  LWIMKitExample
//
//  Created by zhiwen.mizw on 1/1/15.
//  Copyright (c) 2015 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WKBizXpnActionModel;

@interface WKBizXpnPushModel : NSObject

@property (nonatomic, copy) NSString *sound;

@property (nonatomic, strong) WKBizXpnActionModel *action;

@property (nonatomic) int64_t timeTolive;

@property (nonatomic) int64_t incrbadge;

@property (nonatomic, strong) NSDictionary *params;

@property (nonatomic, copy) NSString *alertContent;

@property (nonatomic) NSInteger isXpnOff;

@property (nonatomic) NSInteger templateId;

@end

@interface WKBizXpnActionModel : NSObject

@property (nonatomic, copy) NSString *templateKey;

@property (nonatomic, copy) NSString *templateValue;

@end