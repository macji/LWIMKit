//
//  JSONClassField.h
//  OCJSONKitExample
//
//  Created by zhiwen.mizw on 11/28/14.
//  Copyright (c) 2014 zhiwen.mizw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONClassField : NSObject

/**
 *  属性变量名
 */
@property (nonatomic, strong) NSString *fieldName;
/**
 *  属性的类型，{如果是结构体的话，则为nil}
 */
@property (nonatomic, strong) NSString *fieldType;

/**
 *  属性类型转成class
 */
@property (nonatomic, strong, readonly) Class fieldTypeClass;

/**
 *  属性是否为结构体类型
 */
@property (nonatomic) BOOL isStructType;
/**
 *  属性是否为只读类型
 */
@property (nonatomic) BOOL isReadonly;

/**
 *  属性为 id 类型
 */
@property (nonatomic) BOOL isIdType;

@end
