//
//  IMError.h
//  LWIMKitExample
//
//  Created by 云信 on 14-7-10.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 错误码
 */
typedef NS_ENUM(NSUInteger, WKErrorCode)
{
    //公共错误
    /**	 内部系统错误 */
    WK_ERR_CODE_UNKNOWN =	101001,//<! 内部系统错误
    
    /** 参数不合法 */
    WK_ERR_CODE_PARAM_INVALID =	101002,//<!	 参数不合法
    
    /** 系统繁忙 */
    WK_ERR_CODE_SYSTEM_BUSY =	101003,//<!	 系统繁忙
    
    /** 需要登录操作 */
    WK_ERR_CODE_AUTH_INVALID =	101004,//<!	 需要登录操作
    
    /** 上传失败 */
    WK_ERR_CODE_UPLOAD_FAILED =	101005,//<!	 上传失败
    
    /** 存储空间不足（客户端） */
    WK_ERR_CODE_NOT_ENOUGH_SPACE =	101006,//<!	 存储空间不足（客户端）
    
    /** 数据库异常 */
    WK_ERR_CODE_DATABASE_ERROR =	101007,//<!	 数据库异常
    
    //用户错误
    /** openIdSecret不匹配 */
    WK_ERR_CODE_OPENID_NOT_MATCH = 110000,//<!	 openIdSecret不匹配
    
    /** appSecret不匹配 */
    WK_ERR_CODE_APPSECRET_NOT_MATCH = 	110001,//<!	 appSecret不匹配
    
    /** 用户不存在 */
    WK_ERR_CODE_USER_NOT_FOUND = 	110002,//<!	 用户不存在
    
    /** 原openIdSecret错误 */
    WK_ERR_CODE_ORIGIN_OPENID_NOT_MATCH = 	110003,//<!	 原openIdSecret错误
    
    /** 用户已注册 */
    WK_ERR_CODE_USER_ALREADY_EXIST = 	110004,//<!	 用户已注册
    
    /** 不规范的用户tag */
    WK_ERR_CODE_USER_TAG_INVALID = 	110005,//<!	 不规范的用户tag
    
    /** 无效的手机号 */
    WK_ERR_CODE_MOBILE_INVALID = 	110006,//<!	 无效的手机号
    
    /** 验证码重试次数过多 */
    WK_ERR_CODE_SMSCODE_RETRY_BUSY = 	110007,//<!	 验证码重试次数过多
    
    /** 验证码不存在 */
    WK_ERR_CODE_SMSCODE_NOT_FOUND = 	110008,//<!	 验证码不存在
    
    /** 验证码已过期 */
    WK_ERR_CODE_SMSCODE_EXPIRE = 	110009,//<!	 验证码已过期
    
    /** 错误的验证码 */
    WK_ERR_CODE_SMSCODE_INVALID = 	110010,//<!	 错误的验证码
    
    /** 批量获取超限（这次默认先５０个） */
    WK_ERR_CODE_OVER_MAX_COUNT = 	110011,//<!	 批量获取超限（这次默认先５０个）
    
    /** 一分钟内只能发送一次验证码*/
    WK_ERR_CODE_SMSCODE_FREQUENCY_HIGH = 	110012,//<!	 一分钟内只能发送一次验证码
    
    /** 你想使用的手机号已经被他人占用 */
    WK_ERR_CODE_OTHER_BIND_MOBILE = 	110101,//<!	 你想使用的手机号已经被他人占用
    
    /** 你想使用的昵称已经被他人占用 */
    WK_ERR_CODE_OTHER_USED_NICK = 	110102,//<!	 你想使用的昵称已经被他人占用
    
    //认证错误
    /** app_key不存在 */
    WK_ERR_CODE_APPKEY_NOT_FOUND =	119999,//<!	 app_key不存在
    
    /** domain数据不匹配 */
    WK_ERR_CODE_DOMAIN_NOT_MATCH =		119998,//<!	 domain数据不匹配
    
    /** org数据不匹配 */
    WK_ERR_CODE_ORG_NOT_MATCH =		119997,//<! org数据不匹配
    
    /** app_key不匹配 */
    WK_ERR_CODE_APPKEY_NOT_MATCH =		119996,//<! app_key不匹配
    
    /** app_secret不存在 */
    WK_ERR_CODE_APPSECRET_NOT_FOUND =		119995,//<! app_secret不存在
    
    /** device_id不匹配 */
    WK_ERR_CODE_DEVICEID_NOT_MATCH =		119994,//<! device_id不匹配
    
    /** 删除token错误 */
    WK_ERR_CODE_REMOVE_TOKEN_ERROR =		119993,//<! 删除token错误
    
    /** 生成token错误 */
    WK_ERR_CODE_CREATE_TOKEN_ERROR =		119992,//<! 生成token错误
    
    /** 空的解码串 */
    WK_ERR_CODE_DECODE_TOKEN_ERROR =		119991,//<! 空的解码串
    
    /** 解码串匹配异常 */
    WK_ERR_CODE_DECODE_TOKEN_NOT_MATCH =		119990,//<! 解码串匹配异常
    
    /** refresh_token不存在 */
    WK_ERR_CODE_REFRESH_TOKEN_NOT_FOUND =		119989,//<! refresh_token不存在
    
    /** refresh_token过期 */
    WK_ERR_CODE_REFRESH_TOKEN_EXPIRE =		119988,//<! refresh_token过期
    
    //聊天错误
    /** 不是群主 */
    WK_ERR_CODE_NOT_GROUP_OWNER	= 130000,//<! 不是群主
    
    /** 消息不存在 */
    WK_ERR_CODE_MESSAGE_NOT_FOUND	=	130001,//<! 消息不存在
    
    /** 会话不存在 */
    WK_ERR_CODE_CONVERSATION_NOT_FOUND	=	130002,//<! 会话不存在
    
    /** 用户不在群中 */
    WK_ERR_CODE_NOT_IN_GROUP	=	130003,//<! 用户不在群中
    
    /** 群成员人数超限（最多500） */
    WK_ERR_CODE_GROUP_MEMBER_OVER_MAX_COUNT	=	130004,//<! 群成员人数超限（最多500）
    
    //加签错误
    /** 请求不合法	 安全验签失败 */
    WK_ERR_CODE_REQUEST_SIGN_FAILED =	142001,//<!	 请求不合法	 安全验签失败
    
    //请求其他错误
    /** 请求过于频繁	 用户频繁访问同一个url */
    WK_ERR_CODE_API_REQUEST_FREQUENCY_HIGH =	144001,//<!	 请求过于频繁	 用户频繁访问同一个url
    
    /** 请求过于频繁	 特定ip频繁访问同一个url */
    WK_ERR_CODE_IP_REQUEST_FREQUENCY_HIGH =	144002,//<!	 请求过于频繁	 特定ip频繁访问同一个url
    
    
    
    /////////////////以下为客户端自定义错误码，区间：170000~179999/////////////////////
    WK_ERR_CODE_AUTH_DUPLICATED = 170000,   //<!	 重复登录
};

@protocol IMError <NSObject>

@property (nonatomic, readonly) NSUInteger code;
@property (nonatomic, strong, readonly) NSString *domain;
@property (nonatomic, strong, readonly) NSString *descriptions;

@property (nonatomic, strong, readonly) NSDictionary *userInfo;

@end
