//
//  WKURLProxy.h
//  LWIMKit
//
//  Created by 金申生 on 15-1-29.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * 用于标记一个http请求是否走阿里悟空长连接通道：NSHTTPURLResponse.allHeaderFields是否有这个key
 */
FOUNDATION_EXTERN NSString *const webViewProxyFlagKey;

/**
 * 仅支持http协议，拦截之后走阿里悟空长连接通道
 */

@interface WKURLProxy : NSObject

/**
 * 以host，path组成条件进行拦截：如拦截：http://m.laiwang.com/market/pc/help/index.php
 * @param host  域名，必要字段，如：m.laiwang.com
 * @param path  路径，可以为空，如：/market/pc/help/
 */

+ (void)handleRequest:(NSString*)host path:(NSString*)path;

/**
 * 批量拦截
 * @param array  NSArray<NSDictionary>，dic keys：host & path
 */

+ (void)handleRequests:(NSArray*)array;


/**
 * 根据自定义条件进行拦截
 * @param predicate  Match on any property of NSURL, e.g. "scheme MATCHES 'http' AND host MATCHES 'www.google.com'"
 */

+ (void)handleRequestsMatching:(NSPredicate *)predicate;

@end
