//
//  WKRelationServiceProtocol.h
//  LWIMKitExample
//
//  Created by 金申生 on 15/4/20.
//  Copyright (c) 2015 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import "WKFollowModel.h"
#import "WKAliasModel.h"
#import "WKBlacklistModel.h"
#import "IMError.h"

@protocol WKRelationServiceProtocol <NSObject>

/**
 * 修改备注名
 * @param alias: 备注名
 * @param openId: 用户id
 * @param successBlock: 成功后调用
 * @param failureBlock: 失败后调用
 */
- (void)updateAlias:(NSString*)alias
             openId:(int64_t)openId
       successBlock:(void (^)(WKAliasModel *result))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取本地备注名
 *
 *  @param openId:   用户id
 *  @return:         WKAliasModel对象
 */
- (WKAliasModel*)aliasByOpenId:(int64_t)openId;

/**
 *  获取本地所有备注名
 *
 *  @retuen: WKAliasModel对象数组
 */
- (NSArray*)aliases;

/**
 *  关注对方
 *
 *  @param openId       用户ID
 *  @param successBlock 成功回调 回调参数@see WKFollowModel
 *  @param failureBlock 失败回调
 */
- (void)follow:(int64_t)openId
  successBlock:(void (^)(WKFollowModel *result))successBlock
  failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  取消关注对方
 *
 *  @param openId       用户ID
 *  @param successBlock 成功回调 回调参数@see WKFollowModel
 *  @param failureBlock  失败回调
 */
- (void)unfollow:(int64_t)openId
    successBlock:(void (^)(WKFollowModel *result))successBlock
    failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取我关注的用户列表
 *
 *  @return WKFollowModel数组
 */
- (NSArray *)followings;

/**
 *  获取关注我的用户列表
 *
 *  @return WKFollowModel数组
 */
- (NSArray *)followers;

/**
 *  获取我与用户的Follow状态 @see WKFollowStatus
 *
 *  @param openId   用户Id
 *
 *  @return WKFollowStatus
 */
- (WKFollowStatus)followStatusByOpenId:(int64_t)openId;

#pragma mark - 黑名单

/**
 *  加入黑名单
 *
 *  @param openId       用户Id
 *  @param successBlock 成功回调 回调参数@see WKBlacklistModel
 *  @param failureBlock 失败回调
 */
- (void)addToBlacklist:(int64_t)openId
          successBlock:(void (^)(WKBlacklistModel *result))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  移除黑名单
 *
 *  @param openId: 用户Id
 *  @param successBlock: 成功回调 回调参数@see WKBlacklistModel
 *  @param failureBlock: 失败回调
 */
- (void)removeFromBlacklist:(int64_t)openId
               successBlock:(void (^)(WKBlacklistModel *result))successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取黑名单列表
 *
 *  @return NSArray: 黑名单数组 array of @see WKBlacklistModel
 */
- (NSArray *)blacklist;

/**
 *  获取黑名单状态
 *
 *  @param openId   用户Id
 *
 *  @return WKBlacklistStatus
 */
- (WKBlacklistStatus)blacklistStatusByOpenId:(int64_t)openId;


@end