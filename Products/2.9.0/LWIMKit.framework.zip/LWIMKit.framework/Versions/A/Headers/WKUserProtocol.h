//
//  WKBizProfileProtocol.h
//  LWIMKit
//
//  Created by 阳翼 on 14-11-10.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  性别枚举定义
 */
typedef NS_ENUM(NSInteger, WKGenderType)
{
    WKGenderUnknown = 0,//未知
    WKGenderMale = 1,//男
    WKGenderFemale = 2,//女
};


/**
 *  用户资料模型
 */
@protocol WKUserProtocol <NSObject>

/**
 *  用户的openId
 */
- (int64_t)openId;

/**
 *  昵称（10个字符以内，可以是中文，但不能有特殊标点符号）
 */
@property(nonatomic, copy) NSString* nickname ;

/**
 *  昵称的拼音
 */
- (NSString *)nickPinyin;

/**
 *  性别
 */
@property(nonatomic, assign) WKGenderType gender;

/**
 *  头像，一般是url
 */
@property(nonatomic, copy) NSString* avatar;

/**
 *  备注
 */
@property(nonatomic, copy) NSString* remark;

/**
 *  出生日期
 */
@property(nonatomic, assign) int64_t birthday;

/**
 *  城市
 */
@property(nonatomic, copy) NSString* city;

/**
 *  手机区号
 */
@property(nonatomic, copy) NSString* countryCode;

/**
 *  手机号码
 */
@property(nonatomic, copy) NSString* mobile;

/**
 *  标示用户是否激活
 */
- (BOOL)isActive;

/**
 *  扩展字段{数据字典类型，用于自定义key value值}
 *  该字段的json字符串长度不能超过4000
 */
@property(nonatomic, copy) NSDictionary* extension;

/**
 *  标示用户资料的版本
 */
- (long)remoteServerVersion;

@end

