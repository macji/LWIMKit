//
//  WKProfileServiceProtocol.h
//  LWIMKit
//
//  Created by 阳翼 on 6/11/14.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol WKUserProtocol, IMError;


@protocol WKProfileServiceProtocol <NSObject>

/**
 *  是否启用profile服务
 */
@property (nonatomic, assign) BOOL profileModuleEnabled;

/**
 *  获取最新的个人资料
 *
 *  @param openId 用户id
 *
 *  @return 返回个人资料对象
 */
- (id<WKUserProtocol>)latestUserProfileByOpenId:(int64_t)openId;

/**
 *  获取个人资料，只要openId合理，一定返回实例。本地若有新数据立即返回，如通过远程获取到的，将会抛出WKUserUpdatedNotify通知
 *
 *  @param openId      用户id
 *  @param version     版本号，若传入0则取缓存，若大于0，则比较远程和缓存的version来决定是否去服务器获取
 *
 *  @return 返回个人资料对象，可能返回nil
 */
- (id<WKUserProtocol>)userProfileByOpenId:(int64_t)openId version:(long)version;


/**
 *  从本地获取个人资料
 *
 *  @param openId 用户id
 *
 *  @return 返回个人资料对象，可能返回nil
 */

- (id<WKUserProtocol>)loadLocalUserProfileByOpenId:(int64_t)openId;

/**
 *  从本地获取个人资料
 *
 *  @param openIds 用户id数组
 *
 *  @return 返回个人资料数组：array of id<WKUserProtocol>，可能返回nil
 */

- (NSArray *)loadLocalUserProfilesByOpenIds:(NSArray *)openIds;

/**
 *  获取个人资料，内部缓存有数据则直接返回，没数据则从服务端拉取
 *
 *  @param openId       用户id
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)loadUserProfileByOpenId:(int64_t)openId
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料，内部有数据缓存 (国家码为+86)
 *
 *  @param mobile       手机号码
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)loadUserProfileByMobile:(NSString *)mobile
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取个人资料，内部有数据缓存
 *
 *  @param mobile       手机号码
 *  @param countryCode  国家码（号码地区限定），传入nil默认为+86
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)loadUserProfileByMobile:(NSString *)mobile
                    countryCode:(NSString *)countryCode
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取个人资料，内部有数据缓存
 *
 *  @param openIds          openId的数组
 *  @param successBlock     成功回调
 *      @param list         WKUserProtocol的数组
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadUserProfilesByOpenIds:(NSArray *)openIds
                     successBlock:(void (^)(NSArray *list))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料，内部有数据缓存
 *
 *  @param mobiles          手机号码数组
 *  @param isCreateNew      如果没有该用户，是否需要新建用户
 *  @param successBlock     成功回调
 *      @param bizProfile   获取到的个人资料
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadUserProfilesByMobiles:(NSArray *)mobiles
                      isCreateNew:(bool)isCreateNew
                     successBlock:(void (^)(NSArray *list))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料，只返回本地数据
 *
 *  @param mobiles          手机号码数组
 *  @param countryCode      国家码（号码地区限定），传入nil默认为+86
 *  @return 返回个人资料数组：array of id<WKUserProtocol>
 */
- (NSArray *)userProfilesByMobiles:(NSArray *)mobiles countryCode:(NSString *)countryCode;


/**
 *  更新个人资料，成功后更新到缓存
 *
 *  @param userProfile      新个人资料
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)updateUserProfile:(id<WKUserProtocol>)userProfile
             successBlock:(void (^)(void))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;


/**
 *  更新个人资料
 *
 *  @param userProfile          新个人资料(avatar字段支持本地路径和远程地址；profile中的字段为空则不会更新该字段)
 *  @param successBlock         成功回调
 *      @param user             更新后的个人资料
 *  @param failureBlock         失败回调
 *      @param error            错误信息
 */
- (void)updateProfile:(id<WKUserProtocol>)userProfile
         successBlock:(void (^)(id<WKUserProtocol> user))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新本人昵称
 *
 *  @param newNickname      新昵称
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)updateMyNickname:(NSString *)newNickname
            successBlock:(void (^)(void))successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像，成功后也更新到缓存
 *
 *  @param uri              新头像(支持本地路径和远程地址)
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)updateMyAvatar:(NSString *)uri
          successBlock:(void (^)(void))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;


/**
 *  更新本人头像，成功后也更新到缓存
 *
 *  @param uri              新头像(支持本地路径和远程地址)
 *  @param successBlock     成功回调
 *      @param url          更新后的头像地址
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)updateAvatarWithUri:(NSString *)uri
               successBlock:(void (^)(NSString *url))successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像
 *
 *  @param image                    新头像（JPEG格式）
 *  @param compressionQuality       上传图片时的压缩比（1为最大压缩，0为最少压缩）
 *  @param successBlock             成功回调
 *      @param url                  更新后的头像地址
 *  @param failureBlock             失败回调
 *      @param error                错误信息
 */
- (void)updateAvatarWithJPEGImage:(UIImage *)image
               compressionQuality:(CGFloat)compressionQuality
                     successBlock:(void (^)(NSString *url))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像
 *
 *  @param image                    新头像（PNG格式）
 *  @param successBlock             成功回调
 *      @param url                  更新后的头像地址
 *  @param failureBlock             失败回调
 *      @param error                错误信息
 */
- (void)updateAvatarWithPNGImage:(UIImage *)image
                    successBlock:(void (^)(NSString *url))successBlock
                    failureBlock:(void (^)(id<IMError> error))failureBlock;

@end