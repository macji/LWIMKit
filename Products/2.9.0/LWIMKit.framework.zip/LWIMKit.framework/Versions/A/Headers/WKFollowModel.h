//
//  WKFollowModel.h
//  LWIMKitExample
//
//  Created by 金申生 on 15/10/14.
//  Copyright © 2015年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  关注状态枚举类型
 */
typedef NS_ENUM(NSInteger, WKFollowStatus) {
    
    /** 没有关注 */
    WKFollowStatusNone      = -1,
    
    /** 我关注的 */
    WKFollowStatusFollowing = 0,
    
    /** 关注我的 */
    WKFollowStatusFollower  = 1,
    
    /** 相互关注 */
    WKFollowStatusBoth      = 2
};


/**
 *  关注数据模型
 */
@interface WKFollowModel : NSObject

/**
 *  用户id
 */
@property(nonatomic, assign) int64_t openId;

/**
 *  关注状态
 */
@property(nonatomic, assign) WKFollowStatus status;

/**
 *  最新修改时间
 */
@property (nonatomic, assign) int64_t lastModify;

@end
