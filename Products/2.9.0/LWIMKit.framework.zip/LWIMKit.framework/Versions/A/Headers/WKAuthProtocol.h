//
//  WKAuthProtocol.h
//  LWIMKit
//
//  Created by 香象 on 14-8-19.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WKNotificationDefine.h"

/**
 *  阿里悟空网络状态定义
 */
typedef NS_ENUM(NSUInteger, WKNetworkStatus)
{
    /** 没有网络 */
    WKNetworkNotReachable = 1,
    
    /** 2G */
    WKNetworkReachableVia2G,
    
    /** 3G */
    WKNetworkReachableVia3G,
    
    /** 2/3G */
    WKNetworkReachableVia3GOr2G,
    
    /** 4G */
    WKNetworkReachableVia4G,
    
    /** WWAN */
    WKNetworkReachableViaWWAN,
    
    /** WiFi */
    WKNetworkReachableViaWiFi,
    
    /** 其他网络 */
    WKNetworkReachableViaOther
};

/**
 *  阿里悟空链接状态
 */
typedef NS_ENUM(NSUInteger, WKSDKConnectStatus)
{
    /** 无链接 */
    WKSDKNoConnect = 0,
    
    /** 正在链接 */
    WKSDKConnecting,
    
    /** 连接失败 */
    WKSDKConnectFail,
    
    /** 通道连接成功，非认证，只允许非认证接口通信 */
    WKSDKConnected,
    
    /** 通道连接并认证成功 */
    WKSDKGrantedConnected
};


/**
 *  阿里悟空IM开发环境定义
 */
typedef NS_ENUM(NSInteger, WKEnvironmentType)
{
    /** 线上环境 */
    WKEnvironmentDistribution   = 0,
    
    /** 沙箱环境 */
    WKEnvironmentDaily          = 2,
    
    /** 预发环境 */
    WKEnvironmentPrerelease     = 3,
};


/**
 * mediaId所用到的几种环境
 */
typedef NS_ENUM(NSInteger, MediaIdEnvironmentType)
{
    /** 测试环境 */
    MediaIdEnvironmentDaily = 1,
};


/// 自动登录返回值状态
typedef NS_ENUM(NSUInteger, WKAutoLoginStatus)
{
    /** 离线登录，实际上连接建立失败 */
    WKAutoLoginOffline = 0,
    
    /** 登录成功，连接成功建立 */
    WKAutoLoginOnline = 1,
};

/** 登录类型 */
typedef NS_ENUM(NSInteger, WKLoginType)
{
    /** 未登录 */
    WKLoginTypeUnknow     = -1,
    
    /** 以用户id登录 */
    WKLoginTypeOpenId     = 0,
    
    /** 以设备id登录，功能有限：目前仅支持消息推送 */
    WKLoginTypeDeviceId   = 1,
};


/**
 *  终端类型定义
 */
typedef NS_ENUM(NSInteger, WKDeviceType)
{
    /**
     * web
     */
    WKDeviceWebType = 0,
    
    /**
     * app
     */
    WKDeviceAppType = 1,
    
    /**
     * 全部类型
     */
    WKDeviceAllType = 2,
};


@class WKAlarm;
@protocol IMError;


/**
 *  阿里悟空认证协议，要使用阿里悟空的服务，如即时消息、语音视屏通话等，必须先通过平台认证接口登录
 */
@protocol WKAuthProtocol<NSObject>

@required

/**
 *  当前DeviceID（不建议用户设置，如需设置请在登录之前操作）
 */
@property (nonatomic, strong) NSString *deviceID;


/**
 *  认证请求
 *
 *  @param domain       三方app在其企业的业务线
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param openId       用户在domain下的唯一id，可以理解为userId
 *  @param nonce        随机数，由阿里悟空提供的算法生成，有效期5分钟
 *  @param timestamp    时间戳，由阿里悟空提供的算法生成，有效期5分钟
 *  @param signature    签名，由阿里悟空提供的算法生成，有效期5分钟
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)loginWithDomain:(NSString *)domain
                 appKey:(NSString *)appkey
                 openId:(int64_t)openId
                  nonce:(NSString *)nonce
              timestamp:(int64_t)timestamp
              signature:(NSString *)signature
           successBlock:(void (^)(NSDictionary *authInfo))successBlock
           failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  认证请求（此种登录方式，功能有限）
 *
 *  @param domain       三方app在其企业的业务线
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param deviceId     设备id（保证唯一性）：用户可以用自己的算法，也可以用[UTDevice utdid]生成设备id
 *  @param nonce        随机数，由阿里悟空提供的算法生成，有效期5分钟
 *  @param timestamp    时间戳，由阿里悟空提供的算法生成，有效期5分钟
 *  @param signature    签名，由阿里悟空提供的算法生成，有效期5分钟
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,appKey,deviceId
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)loginWithDomain:(NSString *)domain
                 appKey:(NSString *)appkey
               deviceId:(NSString *)deviceId
                  nonce:(NSString *)nonce
              timestamp:(int64_t)timestamp
              signature:(NSString *)signature
           successBlock:(void (^)(NSDictionary *authInfo))successBlock
           failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  注册用户接口，若注册成功后直接登录成功
 *
 *  @param openId     用户在domain下的唯一id，可以理解为userId
 *  @param openSecret 对应用户的密钥不可逆hash值
 *  @param appKey     三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret  appKey的私钥
 *  @param orgnizationId  企业id
 *  @param domain     三方app在其企业的业务线
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)registerWithOpenId:(int64_t)openId
                openSecret:(NSString *)openSecret
                    appKey:(NSString *)appKey
                 appSecret:(NSString *)appSecret
             orgnizationId:(NSString *)orgnizationId
                    domain:(NSString *)domain
              successBlock:(void (^)(NSDictionary *authInfo))successBlock
              failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;


/**
 *  认证请求(如果此用户不存在，内部会注册此用户)
 *
 *  @param openId     用户在domain下的唯一id，可以理解为userId
 *  @param openSecret 对应用户的密钥不可逆hash值
 *  @param appKey     三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret  appKey的私钥
 *  @param orgnizationId  企业id
 *  @param domain     三方app在其企业的业务线
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock 发起失败后回调
 *          @param error    错误信息
 */
- (void)loginWithOpenId:(int64_t)openId
             openSecret:(NSString *)openSecret
                 appKey:(NSString *)appKey
              appSecret:(NSString *)appSecret
          orgnizationId:(NSString *)orgnizationId
                 domain:(NSString *)domain
           successBlock:(void (^)(NSDictionary *authInfo))successBlock
           failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;


/**
 *  认证请求
 *
 *  @param domain       三方app在其企业的业务线
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param secretToken  secretToken因子包含orgid,openid,opensecret,appkey,appsecret
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)loginWithDomain:(NSString *)domain
                 appKey:(NSString *)appkey
            secretToken:(NSString *)secretToken
           successBlock:(void (^)(NSDictionary *authInfo))successBlock
           failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;




/**
 *  请求验证码，将以短信的方式发送到指定的手机上
 *  @param orgnizationId 企业id
 *  @param domain       三方app在其企业的业务线
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret    appSecret
 *  @param mobile       接收验证码的手机号码
 *  @param successBlock 发起成功后回调
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)requestSMSWithOrg:(NSString *)orgnizationId
                   domain:(NSString *)domain
                   appKey:(NSString *)appKey
                appSecret:(NSString *)appSecret
                 toMobile:(NSString *)mobile
             successBlock:(void (^)(void))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;

/**
 *  使用短信验证码登录
 *
 *  @param orgnizationId 企业id
 *  @param domain       三方app在其企业的业务线
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret    appSecret
 *  @param mobile       手机号码
 *  @param code         短信验证码
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock 发起失败后回调
 *          @param error 错误信息
 */
- (void)loginBySMSWithOrg:(NSString *)orgnizationId
                   domain:(NSString *)domain
                   appKey:(NSString *)appKey
                appSecret:(NSString *)appSecret
                   mobile:(NSString *)mobile
                     code:(NSString *)code
             successBlock:(void (^)(NSDictionary *authInfo))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;


/**
 *  登录接口
 *
 *  @param appKey           三方app在阿里悟空IM平台申请的app唯一id
 *  @param domain           三方app在其企业的业务线
 *  @param openId           用户在domain下的唯一id，可以理解为userId
 *  @param refreshToken     三方app从悟空服务器获取的refreshToken
 *  @param accessToken      三方app从悟空服务器获取的accessToken
 *  @param successBlock     发起成功后回调
 *          @param authInfo authInfo中包含domain,nickName,openId,appKey,cmd
 *  @param failureBlock     发起失败后回调
 *          @param error    错误信息
 */
- (void)loginWithAppKey:(NSString *)appKey
                 domain:(NSString *)domain
                 openId:(int64_t)openId
           refreshToken:(NSString *)refreshToken
            accessToken:(NSString *)accessToken
           successBlock:(void (^)(NSDictionary *authInfo))successBlock
           failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;

/**
 *  初始化阿里悟空IM平台后，根据需要是否直接自动登录，比如上次已经登录某用户OpenId，当再次启动时可以直接免登
 *  如果发现token失效，平台会抛出WKAuthTokenInvalidNotification通知
 *  @param  openId   你需要自动启动哪一个用户的OpenId 如果传入0表示用latestAuthInfo登录
 *  @param  needAutoLogin 是否需要自动登录，如果上次成功登录传入YES，将自动启动阿里悟空IM，传入NO不会启动阿里悟空IM
 *  @param  completion 启动结果
 *      @param status 一个表示有网状态启动，一个是离线启动
 */
- (void)launchEngineWithOpenId:(int64_t)openId
                 needAutoLogin:(BOOL)needAutoLogin
                    completion:(void (^)(WKAutoLoginStatus status))completion __deprecated_msg("请使用：autoLoginWithCompletion");


/**
 *  自动登录：如果发生token失效，平台会抛出WKAuthTokenInvalidNotification通知，可替换launchEngineWithOpenId方法
 *  @param  completion 结果回调函数
 *      @param success YES：自动登录成功，NO：自动登录失败
 *      @param type 登录类型：用户id登录 or 设备id登录
 */
- (void)autoLoginWithCompletion:(void (^)(BOOL success, WKLoginType type))completion;


/**
 *  登出接口，将释放所有资源
 *
 *  @param completion 注销完成回调
 *
 */
- (void)logoutWithCompletion:(void (^)(void))completion;


/**
 *  获取当前的登录方式
 */
- (WKLoginType)loginType;


/**
 *  将终端踢下线接口(目前只支持踢web端下线)
 *  @param type             要踢出的终端类型
 *  @param message          提示消息
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *          @param error    错误信息
 */
- (void)kickDeviceWithClientType:(WKDeviceType)type
                         message:(NSString *)message
                    successBlock:(void (^)(void))successBlock
                    failureBlock:(void (^)(id<IMError> error))failureBlock;


@optional

/**
 *  注册各模块版本号，请在app启动后，用户登录或自动登录之前调用
 *  @param module   模块名称
 *  @param version  模块的版本号
 */
- (void)registerModule:(NSString *)module withVersion:(int)version;

/**
 *  获取各模块版本号
 *
 *  @return 模块版本号
 */
- (NSString *)getModuleVersion __deprecated_msg("不要紧张，只是换个名字啦，请使用：moduleVersion");

/**
 *  获取各模块版本号
 *
 *  @return 模块版本号
 */
- (NSString *)moduleVersion;

/**
 *  最后一次成功登录的信息存储，包含domain,nickname,openId
 */
- (NSDictionary *)latestAuthInfo;

/**
 *  设置当前登录用户的nickname，请在登录成功后设置
 *
 *  @param nickname 设置当前登录用户的nickname，用于apns推送。
 */
- (void)setNickname:(NSString *)nickname;

/**
 *  当前latestOpenId
 */
- (int64_t)latestOpenId;

/**
 *  当前latestScopeMD5
 */
- (NSString *)latestScopeMD5;

/**
 *  当前 currentOpenId
 */
- (int64_t)currentOpenId;

/**
 *  当前 currentScopeMD5
 */
- (NSString *)currentScopeMD5;

/**
 *  当前AppKey
 *
 *  @return 当前AppKey
 */
- (NSString *)getLWPAppKey __deprecated_msg("不要紧张，只是换个名字啦，请使用：appKey");

/**
 *  当前AppKey
 *
 *  @return 当前AppKey
 */
- (NSString *)appKey;

/**
 *  当前AppSecret
 *  
 *  @return 当前AppSecret
 */
- (NSString *)appSecret;

/**
 *  当前AccessToken
 */
-( NSString *)accessToken;

/**
 *  判断是否已经登录
 *
 *  @return 已经登录返回YES；反之返回NO
 */
- (BOOL)isLogin;

/**
 *  设置SDK环境
 */
+ (void)setEnvironment:(WKEnvironmentType)environment;

/**
 *  获取当前SDK环境
 *
 *  @return 当前SDK环境
 */
+ (WKEnvironmentType)environment;

/**
 *  业务UserAgent, "dingtalk:xxxxx" 格式由业务自定义，业务客户端服务端自协商，悟空仅提供一个通道，建立长连接之前设置有效。
 *
 *  @param bizUserAgent 用户自定义的UserAgent数据
 */
+ (void)setBizUserAgent:(NSString *)bizUserAgent __deprecated_msg("不要紧张，只是换个名字啦，请使用：setCustomUserAgent:");

/**
 *  业务UserAgent, "dingtalk:xxxxx" 格式由业务自定义，业务客户端服务端自协商，悟空仅提供一个通道，建立长连接之前设置有效。
 *
 *  @param customUserAgent 用户自定义的UserAgent数据
 */
+ (void)setCustomUserAgent:(NSString *)customUserAgent;

/**
 *  获取业务UserAgent
 *
 *  @return 业务UserAgent
 */
+ (NSString *)getBizUserAgent __deprecated_msg("不要紧张，只是换个名字啦，请使用：customUserAgent");

/**
 *  获取业务UserAgent
 *
 *  @return 业务UserAgent
 */
+ (NSString *)customUserAgent;

/**
 *  获取系统UserAgent
 *
 *  @return 系统UserAgent
 */
+ (NSString *)getUserAgent __deprecated_msg("不要紧张，只是换个名字啦，请使用：userAgent");

/**
 *  获取系统UserAgent
 *
 *  @return 系统UserAgent
 */
+ (NSString *)userAgent;

/**
 *  设置长连接白名单
 */
- (void)setWhiteUrls:(NSArray *)urls;

/**
 *  启动长连接：在调用白名单中的函数前，需要先启动, 因为在这个时间，IM不会自动启动长连接.
 *
 *  @param appKey 阿里悟空appKey
 */
- (void)startLWPWithAppKey:(NSString *)appKey;

/**
 *  启动长连接：在调用白名单中的函数前，需要先启动, 因为在这个时间，IM不会自动启动长连接.
 *
 *  @param appKey 阿里悟空appKey
 *  @param appSecret 应用私钥
 */
- (void)startLWPWithAppKey:(NSString *)appKey appSecret:(NSString *)appSecret;

/**
 *  设置长连接 cache header
 */
- (void)setCacheHeaders:(NSMutableDictionary *)cacheHeaders;

/**
 *  获取长连接 cache header
 */
- (NSMutableDictionary *)getCacheHeaders __deprecated_msg("不要紧张，只是换个名字啦，请使用：cacheHeaders");

/**
 *  获取长连接 cache header
 */
- (NSMutableDictionary *)cacheHeaders;

@end
