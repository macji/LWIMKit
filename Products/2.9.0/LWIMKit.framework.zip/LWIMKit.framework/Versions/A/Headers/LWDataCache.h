//
//  LWDataCache.h
//  LWCache
//
//  Created by Lai Vingel on 11/23/13.
//  Copyright (c) 2013 Alibaba Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const LWDataCacheStat;                // 缓存字典Key
extern NSString *const LWDataCacheStatTotal;           // 缓存条数
extern NSString *const LWDataCacheStatDiskSpace;       // 缓存占用磁盘总空间
extern NSString *const LWDataCacheStatQueryTimes;      // 缓存查询次数
extern NSString *const LWDataCacheStatHitDisk;         // 磁盘缓存命中次数
extern NSString *const LWDataCacheStatHitMemory;       // 内存缓存命中次数


//! 来往缓存类, 主要特性有线程安全、缓存池，支持 LRU 与 Expire Cache 等
@interface LWDataCache : NSObject

//! 全局缓存池
+ (instancetype)sharedPool;

//! 所有已缓存池列表
+ (NSArray *)allCachedPools;

//! 根据给定的名字初始化缓存池，并将实例也缓存起来以便共享
+ (instancetype)cachePoolWithName:(NSString *)poolName;

//! 清理所有缓存池
+ (void)cleanPools;

//! 清空所有缓存池
+ (void)purgePools;


//! 根据给定的名字初始化缓存池
- (instancetype)initWithPoolName:(NSString *)poolName;

//! 根据指定key获取缓存
- (NSData *)dataForKey:(NSString *)key;
//! 设置指定 key 的缓存
- (void)setData:(NSData *)data forKey:(NSString *)key;
//! 设置过期时间后，将根据过期时间进行清理
- (void)setData:(NSData *)data forKey:(NSString *)key withTimeoutInterval:(NSTimeInterval)timeoutInterval;

- (id<NSCoding>)objectForKey:(NSString *)key;
- (void)setObject:(id<NSCoding>)anObject forKey:(NSString *)key;
- (void)setObject:(id<NSCoding>)anObject forKey:(NSString *)key withTimeoutInterval:(NSTimeInterval)timeoutInterval;


//! 获取指定Key的缓存文件路径
- (NSString *)cachePathForKey:(NSString *)key;

//! 是否已缓存到磁盘
- (BOOL)hasCacheForKey:(NSString*)key;

//! 是否已缓存到内存
- (BOOL)hasCacheForKeyInMemory:(NSString*)key;

//! 删除指定 Key 缓存
- (void)removeCacheForKey:(NSString *)key;

//！清空所有磁盘缓存
- (void)purgeDisk;

//！清理过期磁盘缓存
- (void)cleanDisk;

//! 返回缓存统计数据
- (NSDictionary *)statistics;

//! 返回当前缓存池占用磁盘空间
- (u_int64_t)poolDiskSize;

//！检查是否需要清理
+ (void)cleanPoolsIfNeeded;

//! 清理内存缓存
+ (void)cleanMemory;

//! 缓存池总大小
+ (unsigned long long)allPoolSize;


//! 缓存池名称
@property (nonatomic, copy) NSString *poolName;

//! 缓存池存储路径
@property (nonatomic, copy, readonly) NSString *poolPath;


@end
