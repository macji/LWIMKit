//
//  WKBizXpnPushModel.h
//  LWIMKit
//
//  Created by zhiwen.mizw on 1/1/15.
//  Copyright (c) 2015 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WKBizXpnActionModel;


/**
 *  APNS消息自定义模型
 */
@interface WKBizXpnPushModel : NSObject


/**
 *  APNS消息体内容
 */
@property (nonatomic, copy) NSString *alertContent;


/**
 *  APNS消息提示音
 */
@property (nonatomic, copy) NSString *sound;


/**
 *  自定义参数
 */
@property (nonatomic, strong) NSDictionary *params;


/**
 *  APNS推送开关
 */
@property (nonatomic) NSInteger isXpnOff;


@property (nonatomic) int64_t timeTolive;

@property (nonatomic) int64_t incrbadge;

@property (nonatomic) NSInteger templateId;

@property (nonatomic, strong) WKBizXpnActionModel *action;

@end



@interface WKBizXpnActionModel : NSObject

@property (nonatomic, copy) NSString *templateKey;

@property (nonatomic, copy) NSString *templateValue;

@end

