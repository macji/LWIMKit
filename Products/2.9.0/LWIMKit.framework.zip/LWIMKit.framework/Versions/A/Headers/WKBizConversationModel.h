//
//  WKBizConversationModel.h
//  LWIMKit
//
//  Created by lingminjun on 14-10-16.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WKBizMessageModel.h"


/**
 *  消息变更通知
 */
FOUNDATION_EXTERN NSString *WKBizConversationDidChangedNotification;//<! 会话变更通知
FOUNDATION_EXTERN NSString *WKBizConversationUserInfoKey;//<! 对应WKBizConversation数据


/// 会话类型
typedef NS_OPTIONS(NSUInteger, WKConversationType)
{
    /// 群聊类型，Many to many
    WKConversationTypeMTM   = 1 << 0,
    
    /// 单聊类型，One to One
    WKConversationTypeOTO   = 1 << 1,
};

/// 会话状态定义
typedef NS_ENUM(NSUInteger, WKConversationStatus)
{
    /// 普通状态，可见状态
    WKConversationStatusNormal      = 0,
    
    /// 标记已经被删除的会话
    WKConversationStatusQuit        = 1,
    
    /// 被踢状态，用户感知后被切换到quit状态
    WKConversationStatusKicked      = 2,
    
    /// 解散状态
    WKConversationStatusDisbanded   = 3,
    
    /// 不可见状态
    WKConversationStatusInvisible   = 4,
    
};

typedef NS_ENUM(NSInteger, WKConversationAddMemberPermission) {
    WKConversationAddMemberPermissionNormal      = 0,   // 默认，群成员都可以加人
    WKConversationAddMemberPermissionOwnerOnly   = 1,   // 只有群主可以加人
};

typedef NS_ENUM(NSInteger, WKConversationTypingType) {
    WKConversationTypingTypeText    = 0,        // 正在输入文本
    WKConversationTypingTypeAudio   = 1,        // 正在输入语音
    WKConversationTypingTypeImage   = 2,        // 正在输入图片
};

typedef NS_ENUM(NSInteger, WKConversationTypingCommand) {
    WKConversationTypingCommandTyping   = 0,    // 告知对方正在输入
    WKConversationTypingCommandCancel   = 1,    // 告知对方已经取消正在输入状态，比如用户情况了输入框，或者直接退出聊天详情页
};

// 会话节点类型
typedef NS_ENUM(NSUInteger, WKConversationNodeType) {
    /** 会话 */
    WKConversationNodeTypeConversation  = 0,
    
    /** 会话容器 */
    WKConversationNodeTypeContainer     = 1
};

/**
 *  会话模型
 */
@protocol WKBizConversation <NSObject>

/**
 *  会话ID
 */
@property (nonatomic, copy, readonly) NSString *conversationId;


/**
 *  聊天的类型（群聊，单聊）
 *  默认是群聊
 */
@property (nonatomic, readonly) WKConversationType conversationType;


/**
 *  会话标题
 */
@property (nonatomic, copy) NSString *title;


/**
 *  会话的头像路径
 */
@property (nonatomic, strong) NSString *icon;


/**
 *  会话创建时间
 */
@property (nonatomic) int64_t createdAt;


/**
 *  会话状态，正常的、已删除的、已退出的
 */
@property (nonatomic, assign) WKConversationStatus status;


/**
 *  会话下面未读消息的数量
 */
@property (nonatomic,readonly) NSInteger unreadCount;


/**
 *  有@我的未读消息message个数,他是unreadCount的子集（unreadAtMeCount <= unreadCount）
 */
@property (nonatomic,readonly) NSInteger unreadAtMeCount;


/**
 *  会话最后一条消息
 */
@property (nonatomic, strong, readonly) id<WKBizMessage> latestMessage;


/**
 *  会话的内容，冗余字段，等同于latestMessage.content的消息内容，三方使用者也可以根据自己的需要设置
 */
@property (nonatomic, copy) NSString *content;


/**
 *  会话最后修改时间，(毫秒),目前仅包含创建时，最后一条latestMessage， sortIndex变更时间
 */
@property (nonatomic, readonly) int64_t latestModifiedAt;


/**
 *  会话最后消息变更时间，冗余字段，等同于latestMessage的时间，(毫秒)
 */
@property (nonatomic, readonly) int64_t latestMessageModifiedAt;


/**
 *  会话的草稿
 */
@property (nonatomic, copy) NSString *draft;


/**
 *  草稿中的 @某某某 列表，要求放入Key:NSNumber<openId>==>Value:NSString<nickname>
 *  与draft字段一起使用
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *draftAtList;

/**
 *  群聊成员总数
 *  单聊：memberCount == 2
 *  群聊：当前群成员总数，实时更新
 */
@property (nonatomic) NSInteger memberCount;

/**
 *  群聊成员 NSArray<WKMember>
 *  本地缓存，不一定是最新的，需要调用membersOfGroup来更新
 */
@property (nonatomic, strong, readonly) NSArray *members;

/**
 *  会话是否提示，NO表示有推送提示，并且有数字标识，YES表示无推送通知、无小红点标识
 */
@property (nonatomic) BOOL disableNotification;

/**
 *  用户对本会话自定义的push提示音，值是提示音的key，需要服务端配置一个key对应的文件名，这个值只有在 disableNotification 为 NO 时才有意义
 */
@property (nonatomic, copy) NSString *notificationSound;

/**
 *  会话其他附加信息，与会话所有成员相关，会话本身属性，拓展业务key-value对，key、value仅限于NSString类型
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *extension;


/**
 *  会话其他附加信息，至于当前用户相关，与会话其他成员无关的信息，拓展业务key-value对，key、value仅限于NSString类型
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *privateExtension;


/**
 *  业务方自定义的tag
 */
@property (nonatomic) NSInteger tag;


/**
 *  会话排序优先级，适用于的场景为：存在置顶的情况，值越大，表示优先级越高，默认0
 */
@property (nonatomic) NSInteger sortIndex;


/**
 *  业务方客户端专用的DB数据扩展字段，不会同步到服务器，方便客户端本地针对会话记录数据
 */
@property (nonatomic, copy) NSString *clientExtension;

/**
 *  群加人权限，@see WKConversationAddMemberAuthority
 */
@property (nonatomic, assign) WKConversationAddMemberPermission addMemberPermission;

/**
 *  会话成员的最大数量限制
 */
@property (nonatomic, assign) int memberLimit;

/**
 *  0非大群，1大群，其他数字可做大群等级扩展使用
 */
@property (nonatomic, assign) int groupLevel;

/**
 *  单聊中对方的openId
 *  如果不是单聊，本属性返回0
 */
@property (nonatomic, assign, readonly) int64_t peerOpenId;

/**
 *  父会话ID
 */
@property(nonatomic, copy, readonly)  NSString *parentId;

/**
 *  会话节点类型
 */
@property(nonatomic, assign, readonly) WKConversationNodeType nodeType;

/**
 *  是否子会话
 */
- (BOOL)isChild;

/**
 * 是否会话容器
 */
- (BOOL)isContainer;

@end

