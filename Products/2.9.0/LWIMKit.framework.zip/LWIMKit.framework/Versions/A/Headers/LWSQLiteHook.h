//
//  LWSQLiteHook.h
//  SQLiteHookDemo
//
//  Created by Lings on 14-5-29.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


#define kLWSQLiteHookInvalidRowId   (-1)


typedef NS_ENUM(NSInteger, LWSQLiteOperationType) {
    LWSQLiteOperationUnknown = 0,
    LWSQLiteOperationInsert,            //新增
    LWSQLiteOperationUpdate,            //更新
    LWSQLiteOperationDelete,            //删除
    LWSQLiteOperationRollback = 100     //回滚：注意：因为db操作回滚了，但ui层的操作只能reload db来保持一致
};


/**
 *  sqlite监控回调block
 *
 *  @param opertation 操作码，参考LWSQLiteOperationType
 *  @param rowId      表格的自增id
 */
typedef void (^LWSQLiteHookCallback)(LWSQLiteOperationType opertation, sqlite_int64 rowId);


typedef void (*LWSQLiteHookUpdateProc)(void *, int, char const *, char const *, sqlite3_int64);
typedef void (*LWSQLiteHookRollbackProc)(void *);


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@interface LWSQLiteHook : NSObject

/**
 *  创建一个SQLite的Hook
 *
 *  @param sqlite               sqlite3指针
 *  @param enableExclusiveHook  是否开启独占sqlite hook，默认为YES
 *
 *  @return 返回Hook对象
 */
+ (instancetype)hookWithSQLite:(sqlite3 *)sqlite;
+ (instancetype)hookWithSQLite:(sqlite3 *)sqlite enableExclusiveHook:(BOOL)enableExclusiveHook;

- (instancetype)initWithSQLite:(sqlite3 *)sqlite;
- (instancetype)initWithSQLite:(sqlite3 *)sqlite enableExclusiveHook:(BOOL)enableExclusiveHook;


// 返回处理update hook的函数指针
- (LWSQLiteHookUpdateProc)updateHookProc;

// 返回处理rollback hook的函数指针
- (LWSQLiteHookRollbackProc)rollbackHookProc;


/**
 *  增加独占的sqlite hook
 */
- (void)enableExclusiveHook;

/**
 *  移除独占sqlite hook，注意：请务必在db close的时候调用此方法
 */
- (void)removeExclusiveHook;


/**
 *  监控db某个表的变化，注意：如果是rollback，则所有观察者都会被回调
 *
 *  @param observer  观察者
 *  @param tableName db表名称
 *  @param callback  回调block, 注意：该block在异步线程中执行
 */
- (void)addObserver:(NSObject *)observer
           forTable:(NSString *)tableName
           callback:(LWSQLiteHookCallback)callback;

/**
 *  移除对db某个表的监控，注意：请务必在观察者dealloc时确保调用此方法
 *
 *  @param observer  观察者
 *  @param tableName db表名称
 */
- (void)removeObserver:(NSObject *)observer
              forTable:(NSString *)tableName;

/**
 *  取消当前所有的hook operation
 */
- (void)cancelAllExistingHookOperations;

@end
