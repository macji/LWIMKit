//
//  WKAttachment.h
//  LWIMKit
//
//  Created by jiaruis on 14-7-30.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CGGeometry.h>


/**
 * 系统模板id
 */
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_START_CHAT;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_START_SECURED_CHAT;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_ADD_MEMBER;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_RM_MEMBER;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_UPDATE_GROUP_TITLE;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_QUIT_GROUP;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_QUIT_GROUP;
FOUNDATION_EXTERN NSString *const WKTemplateID_IM_GROUP_OWNER_CHANGED;

typedef NS_ENUM(NSInteger, WKMessageAttachmentType)
{
    WKMessageAttachmentTypeUnknown     = -1,
    WKMessageAttachmentTypeText        = 1,
    WKMessageAttachmentTypeImage       = 2,
    WKMessageAttachmentTypeAudio       = 4,
    WKMessageAttachmentTypeAudioImage  = 6,                    //声音图片
    WKMessageAttachmentTypeFile        = 8,                    //文件
    WKMessageAttachmentTypeOldLink     = 16,                   //兼容老版本link类型
    WKMessageAttachmentTypeCustom      = 101,                  //自定义附件类型
    WKMessageAttachmentTypeNewLink     = 102,                  //link类型
    WKMessageAttachmentTypeAssistant   = 201,                  //钉钉小助手
};


//宏定义已过期，请使用WKMessageAttachmentType
#define WKAttachmentTypeText        WKMessageAttachmentTypeText
#define WKAttachmentTypeImage       WKMessageAttachmentTypeImage
#define WKAttachmentTypeAudio       WKMessageAttachmentTypeAudio
#define WKAttachmentTypeFile        WKMessageAttachmentTypeFile
#define WKAttachmentTypeLink        WKMessageAttachmentTypeOldLink

/**
 *  消息附件Model
 */
@interface WKAttachment : NSObject

/**
 *  附件类型，默认是五种，文本、图片、语音，文件和通用类型，为了方便上层增加新类型，此处暂时不用枚举类型定义
 *  typedef NS_OPTION(NSUInteger, WKAttachmentType)
 *  {
 *      WKAttachmentText  = 1 << 0,
 *      WKAttachmentImage = 1 << 1,
 *      WKAttachmentAudio = 1 << 2,
 *      WKAttachmentFile  = 1 << 3,
 *      WKAttachmentLink = 1 << 4,
 *      //...
 *
 *      WKAttachmentCustom = 1 << 10,
 *  };
 */
@property (nonatomic) NSInteger attachmentType;

@end

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
#pragma mark - WKAttachment 子类

/**
 *  文本附件
 */
@interface WKAttachmentText : WKAttachment

/**
 *  文本内容
 */
@property (nonatomic, copy) NSString *text;

/**
 *  国际化系统消息模板id
 */
@property (nonatomic, copy) NSString *templateId;

/**
 *  国际化系统消息模板数据
 */
@property (nonatomic, copy) NSArray *templateData;

@end

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -

/**
 *  图片附件
 */
@interface WKAttachmentImage : WKAttachment

/**
 *  图片的mediaId，根据这个生成对应的远程URL
 */
@property (nonatomic, copy) NSString *mediaId;

/**
 *  图片的字节大小
 */
@property (nonatomic) int64_t imageSize;

/**
 *  图片的远程地址
 */
@property (nonatomic, copy, readonly) NSString *imageUrl;

/**
 *  图片的二进制流(取本地缓存)
 */
@property (nonatomic, strong,readonly) NSData *data;

/**
 *  标示图片类型，1为原图，0为默认
 */
@property (nonatomic, assign) NSInteger picType;

/**
 *  图片旋转方向
 */
@property (nonatomic, assign) NSInteger orientation;

/**
 *  图片逻辑像素大小尺寸，即UIImage.size
 *  return image size
 */
- (CGSize)imagePixelSize;

@end

//////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -

/**
 *  语音附件
 */
@interface WKAttachmentAudio : WKAttachment

/**
 *  语音的mediaId，根据这个生成对应的资源URL
 */
@property (nonatomic, copy) NSString *mediaId;

/**
 *  语音的远程地址
 */
@property (nonatomic, copy, readonly) NSString *audioUrl;

/**
 *  语音的二进制流(本地语音缓存)
 */
@property (nonatomic, strong, readonly) NSData *data;

/**
 *  语音持续时间，单位为毫秒
 */
@property (nonatomic, assign) long duration;

/**
 *  语音的波形数据
 */
@property (nonatomic, strong) NSArray *volumns;

/**
 *  是否为边录边传
 */
@property (nonatomic, assign) BOOL isStream;

@end

/**
 *  文件附件
 */
@interface WKAttachmentFile : WKAttachment

/**
 *  文件的mediaId，根据这个生成对应的资源URL
 */
@property (nonatomic, copy) NSString *mediaId;

/**
 *  文件的远程地址
 */
@property (nonatomic, copy, readonly) NSString *fileUrl;

/**
 *  文件名称
 */
@property (nonatomic, copy) NSString *fileName;

/**
 *  文件类型
 */
@property (nonatomic, copy) NSString *fileType;

/**
 *  文件大小
 */
@property (nonatomic, assign) long fileSize;

@end

/**
 *  分享链接附件类型
 */
@interface WKAttachmentLink : WKAttachment

/**
 *  图片mediaId，根据这个生成对应的资源URL
 */
@property (nonatomic, copy) NSString *picUrl;

/**
 *  分享链接url
 */
@property (nonatomic, copy) NSString *shareUrl;

/**
 *  分享标题
 */
@property (nonatomic, strong) NSString *title;

/**
 *  分享内容
 */
@property (nonatomic, copy) NSString *text;

/**
 *  拓展字段，key-value，value只能为NSString类型 @see NSString
 */
@property(nonatomic, strong) NSDictionary *extension;

@end


/**
 *  自定义附件类型 customType定义必须大于200，否则可能会被误认为是上面的基本类型
 */
@interface WKAttachmentCustom : WKAttachment

/**
 *  自定义附件类型
 */
@property(nonatomic) int customType;

/**
 *  自定义附件存放链接(不能为空)
 */
@property(nonatomic, copy) NSString *url;

/**
 *  自定义附件大小
 */
@property(nonatomic) int64_t size;

/**
 *  拓展字段，key-value，value只能为NSString类型 @see NSString
 */
@property(nonatomic, strong) NSDictionary *extension;

@end
