//
//  WKCloudSetting.h
//  LWIMKit
//
//  Created by 金申生 on 15/1/26.
//  Copyright (c) 2015 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  云设置数据模型
 */
@interface WKCloudSetting : NSObject

/**
 *  3rd应用的模块名称(一些保留值不能使用，比如wk_im, wk_user)
 */
@property(nonatomic, copy) NSString* moduleName;

/**
 *  3rd用户的设置项的key值
 */
@property(nonatomic, copy) NSString* key;

/**
 *  3rd用户的设置项的value值
 */
@property(nonatomic, copy) NSString* settingValue;

/**
 *  设置项生效范围, 1代表客户端生效, 2代表服务端生效, 0代码全部生效
 */
@property(nonatomic, strong) NSNumber* effectScope;

@end
