//
//  WKMessageReceiverModel.h
//  LWIMKit
//
//  Created by lingminjun on 14-10-22.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  接收者对于该消息的状态
 */
typedef NS_ENUM(NSUInteger, WKMessageReceiverStatus) {
    
    /** 未送达 */
    WKMessageUndeliveredStatus = 0,
    
    /** 已送达未读 */
    WKMessageDeliveredUnreadStatus = 1,
    
    /** 已读 */
    WKMessageDeliveredReadStatus = 2
};

@protocol WKMessageReceiverModel <NSObject>

/**
 *  消息ID
 */
@property (nonatomic, readonly) int64_t messageId;

/**
 *  消息所在会话ID
 */
@property (nonatomic, copy, readonly) NSString *conversationId;

/**
 *  消息接收者id，就是openId
 */
@property (nonatomic, readonly) int64_t receiverId;

/**
 *  消息接收者的版本
 */
@property (nonatomic, readonly) long receiverTag;


/**
 *  接收者对于该消息的状态（0：未送达 1：已送达未读 2：已读）
 */
@property (nonatomic) WKMessageReceiverStatus messageStatus;

/**
 *  接收者是否已读该消息
 */
-(bool)hasRead;


@end
