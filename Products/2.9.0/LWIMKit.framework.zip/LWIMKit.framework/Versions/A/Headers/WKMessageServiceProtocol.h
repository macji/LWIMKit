//
//  WKMessageServiceProtocol.h
//  LWIMKit
//
//  Created by huichen.xyh on 28/8/14.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#define WK_UTC_DISTANT_FUTURE INT64_MAX

FOUNDATION_EXTERN NSString *WKBizMessageUploadAttachProgressInfoKey;//<! 对应WKBizMessage数据附件上传进度NSNumber<float>

FOUNDATION_EXTERN NSString *WKBizMessageReadNotificationKey;//<! WKBizMessage已读成功/失败通知key


/**
 *  消息变更通知，userInfo{WKBizMessageUserInfoKey : id<WKBizMessage>}
 */
FOUNDATION_EXTERN NSString *WKBizMessageDidChangedNotification;//<! 消息变更通知
FOUNDATION_EXTERN NSString *WKBizMessageUserInfoKey;//<! 对应WKBizMessage数据


@protocol WKBizMessage, WKMessageReceiver, IMError;

/**
 *  会话相关的接口定义
 */
@protocol WKMessageServiceProtocol<NSObject>

@required

#pragma mark - 本地操作

/**
 *  从缓存中取消息
 *
 *  @param messageId      消息id
 *  @param conversationId 会话id
 *
 *  @return 返回消息对象
 */
- (id<WKBizMessage>)messageWithMessageId:(int64_t)messageId conversationId:(NSString *)conversationId;


/**
 *  从缓存中取消息
 *
 *  @param localId        消息的本地id
 *  @param conversationId 会话id
 *
 *  @return 返回消息对象
 */
- (id<WKBizMessage>)messageWithMessageLocalId:(NSString *)localId conversationId:(NSString *)conversationId;

/**
 *  从缓存中筛选消息
 *
 *  @param type  附件类型：若为0，则表示忽略type的过滤条件
 *  @param limit 最大条数
 *  @param conversationId 会话id
 *
 *  @return 返回消息数组
 */
- (NSArray *)latestMessagesWithAttachmentType:(NSInteger)type
                                        limit:(NSInteger)limit
                               conversationId:(NSString *)conversationId;


/**
 *  从缓存中筛选消息
 *
 *  @param type             附件类型：若为0，则表示忽略type的过滤条件
 *  @param senderId         发送者id：若为0，则表示忽略senderId的过滤条件
 *  @param limit            最大条数
 *  @param conversationId   会话id
 *
 *  @return 返回消息数组
 */
- (NSArray *)latestMessagesWithAttachmentType:(NSInteger)type
                                     senderId:(int64_t)senderId
                                        limit:(NSInteger)limit
                               conversationId:(NSString *)conversationId;


/**
 *  删除本地会话的所有消息
 *
 *  @param conversationId 会话id
 *
 *  @return 返回成功/失败
 */
- (BOOL)removeMessagesByConversation:(NSString *)conversationId;

/**
 *  根据消息ID获取本地DB所有接收者的状态 NSArray<WKMessageReceiver>
 *
 *  @param messageId 消息id
 *  @param conversationId 会话id
 *
 *  @return 所有接收者状态列表
 */
- (NSArray *)messageReceiversWithMessageId:(int64_t)messageId inConversation:(NSString *)conversationId;

/**
 *  根据消息ID获取本地DB所有已读或者未读接收者 NSArray<WKMessageReceiver>
 *
 *  @param readStatus 已读或者未读
 *  @param messageId 消息id
 *  @param conversationId 会话id
 *
 *  @return 未读状态接收者列表
 */
- (NSArray *)messageReceiversWithReadStatus:(BOOL)readStatus
                                  messageId:(int64_t)messageId
                             inConversation:(NSString *)conversationId;

/**
 *  将会话中的所有待发送消息都重置成发送失败，主要用于第二次启动后将上一次退出前没有发送的消息重置成failed
 *  @param conversationId 会话id
 */
- (void)resetSendingMessagesToFailedInConversation:(NSString *)conversationId;

/**
 *  更新本地DB的消息的某些字段
 *  @param keyValues 值键对
 *  @param messageId 消息id
 *  @param conversationId 会话id
 */
- (void)setMessageFields:(NSDictionary *)keyValues
               messageId:(int64_t)messageId
          conversationId:(NSString *)conversationId __deprecated_msg("前期开放的私有接口，建议不要调用");

/**
 *  获取时间戳更早本地数据
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param timestamp        游标或时间节点：若为INT64_MAX，则表示获取最新count条消息
 *
 *  @return 返回消息数组：NSArray<id<WKBizMessage>>
 */
- (NSArray *)loadMessagesOfConversation:(NSString *)conversationId
                                  count:(NSUInteger)count
                                 before:(int64_t)timestamp __deprecated;

/**
 *  获取时间戳更早本地数据
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param beforeMessage    游标消息对象：若为nil，则表示获取最新count条消息
 *
 *  @return 返回消息数组：NSArray<id<WKBizMessage>>
 */
- (NSArray *)loadMessagesOfConversation:(NSString *)conversationId
                                  count:(NSUInteger)count
                          beforeMessage:(id<WKBizMessage>)beforeMessage;

/**
 *  从缓存中筛选消息
 *
 *  @param type             附件类型：若为0，则表示忽略type的过滤条件
 *  @param senderId         发送者id：若为0，则表示忽略senderId的过滤条件
 *  @param count            获取消息的数量
 *  @param timestamp        游标或时间节点：若为INT64_MAX，则表示获取最新的count条消息
 *  @param conversationId   会话ID
 *
 *  @return 返回消息数组：NSArray<id<WKBizMessage>>
 */
- (NSArray *)loadMessagesWithAttachmentType:(NSInteger)type
                                   senderId:(int64_t)senderId
                                      count:(NSUInteger)count
                                     before:(int64_t)timestamp
                             inConversation:(NSString *)conversationId;

/**
 *  获取timestamp之后的count条消息
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param timestamp        游标或时间节点
 *
 *  @return 返回消息数组：NSArray<id<WKBizMessage>>
 */
- (NSArray *)loadMessagesOfConversation:(NSString *)conversationId
                                  count:(NSUInteger)count
                                  after:(int64_t)timestamp __deprecated;

/**
 *  获取timestamp之后的count条消息
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param afterMessage     游标消息对象
 *
 *  @return 返回消息数组：NSArray<id<WKBizMessage>>
 */
- (NSArray *)loadMessagesOfConversation:(NSString *)conversationId
                                  count:(NSUInteger)count
                           afterMessage:(id<WKBizMessage>)afterMessage;

/**
 *  获取比给定时间点早的消息
 *
 *  @param cursor 时间点标识
 *  @param offset 偏移数
 *  @param conversationId 会话id
 *
 *  @return 返回消息对象
 */
- (id<WKBizMessage>)loadMessageWithTimeCursor:(int64_t)cursor
                                       offset:(NSInteger)offset
                               inConversation:(NSString *)conversationId;


#pragma mark - 网络操作
/**
 *  获取timestamp之前的count条消息
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param timestamp        游标或时间节点：若为INT64_MAX，则表示获取最新的count条消息
 *  @param successBlock     成功回调
 *      @param msgs         消息数组（升序）：NSArray<id<WKBizMessage>>
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadMessagesOfConversation:(NSString *)conversationId
                             count:(NSUInteger)count
                            before:(int64_t)timestamp
                      successBlock:(void (^)(NSArray *msgs))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;
/**
 *  获取beforeMessage之前的count条消息
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param beforeMessage    游标消息：若为nil，则表示获取最新count条消息
 *  @param successBlock     成功回调
 *      @param msgs         消息数组（升序）：NSArray<id<WKBizMessage>>
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadMessagesOfConversation:(NSString *)conversationId
                             count:(NSUInteger)count
                     beforeMessage:(id<WKBizMessage>)beforeMessage
                      successBlock:(void (^)(NSArray *msgs))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取timestamp之后的count条消息
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param timestamp        游标或时间节点：若为0，则表示取历史最早几条消息
 *  @param successBlock     成功回调
 *      @param msgs         消息数组（升序）：NSArray<id<WKBizMessage>>
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadMessagesOfConversation:(NSString *)conversationId
                             count:(NSUInteger)count
                             after:(int64_t)timestamp
                      successBlock:(void (^)(NSArray *msgs))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;
/**
 *  获取timestamp之后的count条消息
 
 *
 *  @param conversationId   会话ID
 *  @param count            获取消息的数量
 *  @param afterMessage     消息游标：若为0，则表示取历史最早几条消息
 *  @param successBlock     成功回调
 *      @param msgs         消息数组（升序）：NSArray<id<WKBizMessage>>
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadMessagesOfConversation:(NSString *)conversationId
                             count:(NSUInteger)count
                      afterMessage:(id<WKBizMessage>)afterMessage
                      successBlock:(void (^)(NSArray *msgs))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取特定的消息
 *
 *  @param messageId        消息id
 *  @param conversationId   会话id，可以为nil
 *  @param successBlock     成功回调
 *      @param msg          消息对象
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadMessage:(int64_t)messageId
     ofConversation:(NSString *)conversationId
       successBlock:(void (^)(id<WKBizMessage> msg))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  从服务器获取会话里的第一条消息，即最早的消息
 *
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *      @param msg          消息对象
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)loadFirstMessageOfConversation:(NSString *)conversationId
                          successBlock:(void (^)(id<WKBizMessage> msg))successBlock
                          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  发送或者转发消息
 *
 *  @param message          要发送或者转发的消息对象
 *  @param conversationId   要发送到的会话
 *  @param nickName         发送者的名字：如果你填入发送者的名字，将使得apn推送更加准确的显示发送者
 *  @param successBlock     成功回调
 *      @param resultMsg    发送成功之后返回的消息对象，此时的消息才有服务端生成的msgId
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)sendMessage:(id<WKBizMessage>)message
     toConversation:(NSString *)conversationId
           nickName:(NSString *)nickName
       successBlock:(void (^)(id<WKBizMessage> resultMsg))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  批量设置消息为已读状态
 *
 *  @param messageIds       消息ID数组：NSArray<NSNumber<int64_t>>
 *  @param conversationId   消息所在会话的id
 */
- (void)markMessagesToRead:(NSArray *)messageIds ofConversation:(NSString *)conversationId;

/**
 *  删除消息
 *
 *  @param messageId        消息id
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error    错误信息
 */
- (void)removeMessage:(int64_t)messageId
       ofConversation:(NSString *)conversationId
         successBlock:(void (^)(void))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  批量删除消息
 *
 *  @param messageIds       消息id数组：NSArray<NSNumber<int64_t>>
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)removeMessages:(NSArray *)messageIds
        ofConversation:(NSString *)conversationId
          successBlock:(void (^)(void))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  删除消息
 *
 *  @param message          消息对象
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)removeMessage:(id<WKBizMessage>)message
         successBlock:(void (^)(void))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  批量删除本地消息
 *
 *  @param messageIds       消息ID数组：NSArray<NSNumber<int64_t>>
 *  @param conversationId   会话ID
 *
 *  @return YES：成功，NO：失败
 */
- (BOOL)removeMessages:(NSArray *)messageIds ofConversation:(NSString *)conversationId;

/**
 *  回撤消息
 *
 *  @param messageId        消息ID
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)recallMessage:(int64_t)messageId
       ofConversation:(NSString *)conversationId
         successBlock:(void (^)(void))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 * 判断是否回撤一条消息是否允许（是否已发送超过3分钟），该判断仅仅用于本地时间的对比，存在一定误差，最终成功与否由服务端决定，
 * 注：该函数不严谨，只用于判断该消息发送成功到现在是否超过3分钟，最终能否撤回以服务端返回结果为准。
 *
 * @param message   消息对象
 *
 * @return YES：允许撤回，NO：不允许撤回
 */
- (BOOL)isRecallAllowed:(id<WKBizMessage>)message;

/**
 *  更新消息的私有tag
 *
 *  @param tag          私有tag
 *  @param messageId    消息id
 *  @param conversationId 会话id
 *  @param openIds      私有tag所作用的用户
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)updateMessagePrivateTag:(long)tag
                      messageId:(int64_t)messageId
                 ofConversation:(NSString *)conversationId
                        openIds:(NSArray *)openIds
                   successBlock:(void (^)(void))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新消息的私有拓展属性
 *
 *  @param extension    私有拓展属性
 *  @param messageId    消息id
 *  @param conversationId 会话id
 *  @param openIds      私有拓展属性所作用的用户
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)updateMessagePrivateExtension:(NSDictionary *)extension
                            messageId:(int64_t)messageId
                       ofConversation:(NSString *)conversationId
                              openIds:(NSArray *)openIds
                         successBlock:(void (^)(void))successBlock
                         failureBlock:(void (^)(id<IMError> error))failureBlock;



/**
 *  获取消息未读成员的列表，不建议使用，后期将删除
 *
 *  @param messageId      消息id
 *  @param conversationId 会话id
 *  @param successBlock 成功回调
 *      @param members  未读成员列表， NSArray<WKMessageReceiver>
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)loadUnreadReceiversOfMessage:(int64_t)messageId
                      ofConversation:(NSString *)conversationId
                        successBlock:(void (^)(NSArray *members))successBlock
                        failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;

/**
 *  获取消息未读成员的列表，不建议使用，后期将删除
 *
 *  @param openIds      接收者的id，如果传入nil，表示这条消息所有接收者的状态
 *  @param messageId    消息id
 *  @param conversationId 会话id
 *  @param successBlock 成功回调
 *      @param members  未读成员列表， NSArray<WKMessageReceiver>
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 */
- (void)loadUnreadReceivers:(NSArray *)openIds
                  ofMessage:(int64_t)messageId
             ofConversation:(NSString *)conversationId
               successBlock:(void (^)(NSArray *members))successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock __deprecated;

/**
 *  获取所有消息接收者，并触发更新
 *
 *  @param messageId    消息id
 *  @param conversationId 会话id
 *  @param successBlock 成功的回调
 *      @param members  未读成员列表， NSArray<WKMessageReceiver>
 *  @param failureBlock 失败回调
 *      @param error    错误信息
 *
 *  @return 返回本地 NSArray<WKMessageReceiver>
 */

-(NSArray *)loadReceiversOfMessage:(int64_t)messageId
                    ofConversation:(NSString *)conversationId
                      successBlock:(void (^)(NSArray *members))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新消息的拓展属性
 *
 *  @param extension        新的拓展属性(允许extension为空)
 *  @param messageId        消息id
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        错误信息
 */
- (void)updateMessageExtension:(NSDictionary *)extension
                     messageId:(int64_t)messageId
                ofConversation:(NSString *)conversationId
                  successBlock:(void (^)(void))successBlock
                  failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 * 更新消息的撤回状态
 *
 * @param messageId 消息id
 * @param conversationId 会话id
 * @param beforeSaveBlock 保存消息前的回调的二次处理
 *
 * @return 返回被更新的消息
 */
- (id<WKBizMessage>)updateToRecallStatus:(int64_t)messageId
                          conversationId:(NSString *)conversationId
                         beforeBatchSave:(void (^)(id<WKBizMessage> wkBizMessage))beforeSaveBlock;

@end
