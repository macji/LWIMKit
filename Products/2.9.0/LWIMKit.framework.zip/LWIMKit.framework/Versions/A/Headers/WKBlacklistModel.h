//
//  WKBlacklistModel.h
//  LWIMKitExample
//
//  Created by 金申生 on 15/10/15.
//  Copyright © 2015年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  黑名单状态枚举类型
 */
typedef NS_ENUM(NSInteger, WKBlacklistStatus) {
    /** 没有黑名单关系 */
    WKBlacklistStatusNone           = -1,
    
    /** 对方在我的黑名单中 */
    WKBlacklistStatusBlacklisting   = 0,
    
    /**
     *  目前黑名单只支持查对方是否是在自己的黑名单中，不能反查，不应该出现下面两个值
     */
    
    /** 我在对方的黑名单中 */
    WKBlacklistStatusBlacklisted    = 1,
    
    /** 双方互列为黑名单关系 */
    WKBlacklistStatusBoth           = 2
};


/**
 *  黑名单数据模型
 */
@interface WKBlacklistModel : NSObject

/**
 *  用户id
 */
@property(nonatomic, assign) int64_t openId;

/**
 *  黑名单状态
 */
@property(nonatomic, assign) WKBlacklistStatus status;

/**
 *  最新修改时间
 */
@property (nonatomic, assign) int64_t lastModify;

@end
