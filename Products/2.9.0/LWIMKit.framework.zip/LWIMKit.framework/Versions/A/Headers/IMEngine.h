//
//  IMEngine.h
//  LWIMKit
//
//  Created by lingminjun on 14-8-19.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OpenDatabase.h"
#import "LWSQLiteContext.h"
#import "WKAuthProtocol.h"
#import "WKMessageServiceProtocol.h"
#import "WKConversationServiceProtocol.h"
#import "WKPushServiceProtocol.h"
#import "WKAPNSServiceProtocol.h"
#import "WKProfileServiceProtocol.h"
#import "WKCloudSettingServiceProtocol.h"
#import "WKRelationServiceProtocol.h"
#import "WKNoticeHandlerProtocol.h"
#import "WKUserProtocol.h"
#import "WKBizMessageBuilder.h"
#import "WKMember.h"
#import "WKMessageReceiverModel.h"
#import "IMError.h"
#import "WKCloudSetting.h"
#import "WKNotificationDefine.h"

/**
 *  IMEngine是集成所有服务的引擎
 */
@interface IMEngine : NSObject<WKAuthProtocol>

/**
 *  设置SDK环境，需在IMEngine初始化之前调用
 */
+ (void)setEnvironment:(WKEnvironmentType)environment;

/**
 *  获取当前SDK环境
 */
+ (WKEnvironmentType)environment;

/**
 *  业务UserAgent, "dingtalk:xxx" 格式由业务自定义，业务客户端服务端自协商，悟空仅提供一个通道，建立长连接之前设置有效。
 */
+(void)setBizUserAgent:(NSString *)bizUserAgent;

/**
 *  IMEngine单例
 */
+ (instancetype)sharedIMEngine;


#pragma mark IM Service

/**
 *  认证相关service实现
 */
@property (nonatomic, strong, readonly) id<WKAuthProtocol> authService;

/**
 *  会话相关service实现
 */
@property (nonatomic, strong, readonly) id<WKConversationServiceProtocol> conversationService;

/**
 *  消息相关service实现
 */
@property (nonatomic, strong, readonly) id<WKMessageServiceProtocol> messageService;

/**
 *  个人资料相关service实现
 */
@property (nonatomic, strong, readonly) id<WKProfileServiceProtocol> profileService;

/**
 *  云设置相关service实现
 */
@property (nonatomic, strong, readonly) id<WKCloudSettingServiceProtocol> cloudSettingService;


/**
 *  APNS消息推送相关service实现
 */
@property (nonatomic, strong, readonly) id<WKAPNSServiceProtocol> apnsService;

/**
 *  阿里悟空消息推送相关service实现
 */
@property (nonatomic, strong, readonly) id<WKPushServiceProtocol> pushService;

/**
 *  关系相关service实现
 */
@property (nonatomic, strong, readonly) id<WKRelationServiceProtocol> relationService;

/*
 * 设置项：是否启用Profile模块
 */
- (void)setProfileModuleEnabled:(BOOL)enable;

/**
 *  数据库配置接口
 */
- (void)setDatabasePicker:(OpenDatabase * (^)(NSString *scope))databasePicker;


/**
 *  版本号 格式如：1.0.0
 */
- (NSString *)versionString;

/**
 *  最近登录用户的openId
 */
- (int64_t)latestOpenId;

/**
 *  最近登录用户的md5
 */
- (NSString *)latestScopeMD5;//MD5 = uid + "@" + domain，保证域唯一性

/**
 *  最近登录的用户信息
 */
- (id<WKUserProtocol>)latestUserProfile;

/**
 *  非登录状态下，如需使用阿里悟空长连接通道，需要先启动
 *
 *  @param appKey 阿里悟空appKey
 */
- (void)startLWPWithAppKey:(NSString *)appKey __deprecated_msg("后续版本将会废弃此接口，请使用WKAuthProtocol里对应接口");

/**
 *  获取最近一次DB写入时的错误信息
 *
 *  @param errorCode     sqlite error code
 *  @param extendErrCode sqlite error code
 *  @param errorMessage  sqlite error message
 */
- (void)lastDatabaseErrorCode:(int *)errorCode extendedErrCode:(int *)extendErrCode errorMessage:(NSString **)errorMessage;

/**
 *  获取当前的AppKey
 */
- (NSString *)getLWPAppKey;

@end
