//
//  WKAliasModel.h
//  LWIMKitExample
//
//  Created by 金申生 on 15/10/12.
//  Copyright © 2015年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  备注名数据模型
 */
@interface WKAliasModel : NSObject

/**
 *  用户id
 */
@property(nonatomic, assign) int64_t openId;

/**
 *  备注名
 */
@property(nonatomic, copy) NSString* alias;

/**
 *  备注名的拼音
 */
@property(nonatomic, copy) NSString* pinyin;

@end
