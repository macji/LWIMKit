//
//  WKNoticeHandlerProtocol.h
//  LWIMKit
//
//  Created by lingminjun on 14-9-8.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WKNotificationDefine.h"



/**
 *  推送通知处理者协议，调用IMEngine的pushService服务来注册
 */
@protocol WKNoticeHandlerProtocol<NSObject>

@optional

/**
 *  开始处理推送通知
 */
- (void)pushBeforeProcess:(NSString *)messageId value:(id)value;


@required

/**
 *  通知返回值类型
 */
- (Class)returnedValueClass;

/**
 *  成功收到推送通知
 */
- (void)pushReceived:(NSString *)messageId value:(id)value;

/**
 *  收到推送异常
 */
- (void)pushCaught:(NSString *)messageId error:(NSError *)error;

@optional

/**
 *  数据入库前 需要上层处理 避免多次操作db
 */
- (void)beforeSaveModelList:(NSArray *)modelList info:(NSDictionary *)info;

@end

/**
 *  消息推送特殊委托
 */
@protocol WKWessageReceivedNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  消息状态变更推送特殊委托
 */
@protocol WKWessageStatusUpdatedNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  重联推送处理
 */
@protocol WKReconnectNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  消息已读推送通知
 */
@protocol WKMessageIsReadNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end
