//
//  WKBizNotice.h
//  LWIMKit
//
//  Created by 香象 on 18/12/14.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  自定义消息数据模型
 */
@interface WKBizNotice : NSObject

/**
 *  自定义消息类型
 */
@property(nonatomic, strong) NSNumber* type;


/**
 *  自定义消息内容
 */
@property(nonatomic, strong) NSData* content;


/**
 *  消息id
 */
@property(nonatomic, copy) NSString *messageId;


@end
