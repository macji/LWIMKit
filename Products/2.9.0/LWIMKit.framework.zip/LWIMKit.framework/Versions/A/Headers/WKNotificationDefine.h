//
//  WKNotificationDefine.h
//  LWIMKitExample
//
//  Created by 金申生 on 15/10/23.
//  Copyright © 2015年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 *  网络状态变更：userInfo = {WKNetworkStatusUserInfoKey : NSNumber<WKNetworkStatus>}
 */
FOUNDATION_EXTERN NSString *const WKNetworkStatusChangedNotification;
FOUNDATION_EXTERN NSString *const WKNetworkStatusUserInfoKey;


/**
 *  SDK通道连接状态变更：userInfo = {WKSDKConnectStatusUserInfoKey : NSNumber<WKSDKConnectStatus>}
 */
FOUNDATION_EXTERN NSString *const WKSDKConnectStatusChangedNotification;
FOUNDATION_EXTERN NSString *const WKSDKConnectStatusUserInfoKey;


/**
 *  即将登录成功
 */
FOUNDATION_EXTERN NSString *const WKLoginWillFinishNotification;


/**
 *  登录成功：用户相关的初始化可以放这里
 */
FOUNDATION_EXTERN NSString *const WKLoginFinishedNotification;


/**
 *  登出成功：用户相关的清理可以放这里
 */
FOUNDATION_EXTERN NSString *const WKLogoutFinishedNotification;


/**
 *  登录认证失效：用户在其他设备登录或者token过期所致，此时建议调用logout接口
 *  userInfo = {WKAuthTokenInvalidReasonKey : NSString}
 */
FOUNDATION_EXTERN NSString *const WKAuthTokenInvalidNotification;
FOUNDATION_EXTERN NSString *const WKAuthTokenInvalidReasonKey;


/**
 *  token刷新
 */
FOUNDATION_EXTERN NSString *const WKAuthTokenRefreshedNotification;


/**
 *  消息推送：userInfo = {WKMessageUserInfoKey : id<WKBizMessage>}
 */
FOUNDATION_EXTERN NSString *const WKMessageReceivedNotification;
FOUNDATION_EXTERN NSString *const WKMessageUserInfoKey;


/**
 *  消息tag变更：userInfo = {WKMessageUserInfoKey : id<WKBizMessage>}
 */
FOUNDATION_EXTERN NSString *const WKMessageTagUpdatedNotification;


/**
 *  消息状态变更：userInfo = {WKMessagesUserInfoKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessageStatusUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKMessagesUserInfoKey;


/**
 *  消息extension或者撤回状态变更：userInfo = {WKMessagesUserInfoKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessageNoticeUpdatedNotification;


/**
 *  会话变更：userInfo = {WKConversationUserInfoKey : id<WKBizConversation>}
 */
FOUNDATION_EXTERN NSString *const WKConversationUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKConversationUserInfoKey;


/**
 *  会话输入状态变更
 * userInfo{WKConversationTypingStatusUserInfoKey : @[{WKConversationIdKey : NSString,
 *                                                  WKConversationTypingTypeKey : NSNumber<WKConversationTypingType>,
 *                                                  WKConversationTypingCommandKey : NSNumber<WKConversationTypingCommand>}]}
 */
FOUNDATION_EXTERN NSString *const WKConversationTypingStatusUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKConversationTypingStatusUserInfoKey;
FOUNDATION_EXTERN NSString *const WKConversationIdKey;
FOUNDATION_EXTERN NSString *const WKConversationTypingTypeKey;
FOUNDATION_EXTERN NSString *const WKConversationTypingCommandKey;


/**
 *  自定义消息推送：userInfo = {WKCustomDataUserInfoKey : NSArray<WKBizNotice>}
 */
FOUNDATION_EXTERN NSString *const WKCustomDataReceivedNotification;
FOUNDATION_EXTERN NSString *const WKCustomDataUserInfoKey;


/**
 *  消息已读：userInfo = {WKMessagesUserInfoKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessagesReadedNotification;


/**
 *  网络重连成功：userInfo = {WKConversationsUserInfoKey : NSArray<id<WKBizConversation>>, WKMessagesUserInfoKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKReconnectedNotification;
FOUNDATION_EXTERN NSString *const WKConversationsUserInfoKey;


/**
 *  云设置更新：userInfo = {WKCloudSettingsUserInfoKey : NSArray<WKCloudSetting>}
 */
FOUNDATION_EXTERN NSString *const WKCloudSettingUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKCloudSettingsUserInfoKey;


/**
 *  消息已读：userInfo = {WKProfileUserInfoKey : id<WKUserProtocol>, WKOpenIdUserInfoKey : NSNumber<int64_t>}
 *  可以忽略WKOpenIdUserInfoKey，openId可以从WKUserProtocol获取，此处添加只是为了兼容老版本通知
 */
FOUNDATION_EXTERN NSString *const WKProfileUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKProfileUserInfoKey;
FOUNDATION_EXTERN NSString *const WKOpenIdUserInfoKey;


/**
 *  终端在线状态：userInfo = {WKDeviceStatusUserInfoKey : WKDeviceStatus}
 */
FOUNDATION_EXTERN NSString *const WKDeviceStatusUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKDeviceStatusUserInfoKey;


/**
 *  备注名变更：userInfo = {WKAliasUserInfoKey : NSArray<WKAliasModel>}
 */
FOUNDATION_EXTERN NSString *const WKAliasUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKAliasUserInfoKey;


/**
 *  关注变更：userInfo = {WKFollowUserInfoKey : NSArray<WKFollowModel>}
 */
FOUNDATION_EXTERN NSString *const WKFollowUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKFollowUserInfoKey;


/**
 *  黑名单变更：userInfo = {WKBlacklistUserInfoKey : NSArray<WKBlacklistModel>}
 */
FOUNDATION_EXTERN NSString *const WKBlacklistUpdatedNotification;
FOUNDATION_EXTERN NSString *const WKBlacklistUserInfoKey;



#pragma mark - Deprecated Notification


/**
 *  消息推送：userInfo = {WKUserInfoMessageKey : id<WKBizMessage>}
 */
FOUNDATION_EXTERN NSString *const WKMessageReceivedNotify __deprecated_msg("using WKMessageReceivedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoMessageKey __deprecated_msg("using WKMessageUserInfoKey instead");


/**
 *  消息tag变更：userInfo = {WKUserInfoMessageKey : id<WKBizMessage>}
 */
FOUNDATION_EXTERN NSString *const WKMessageTagUpdatedNotify __deprecated_msg("using WKMessageTagUpdatedNotification instead");


/**
 *  消息状态变更：userInfo = {WKUserInfoMessagesKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessageStatusUpdatedNotify __deprecated_msg("using WKMessageStatusUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoMessagesKey __deprecated_msg("using WKMessagesUserInfoKey instead");


/**
 *  消息extension或者撤回状态变更：userInfo = {WKUserInfoMessagesKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessageNoticeUpdateNotify __deprecated_msg("using WKMessageNoticeUpdateNotification instead");


/**
 *  会话变更：userInfo = {WKUserInfoConversationKey : id<WKBizConversation>}
 */
FOUNDATION_EXTERN NSString *const WKConversationUpdatedNotify __deprecated_msg("using WKConversationUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoConversationKey __deprecated_msg("using WKConversationUserInfoKey instead");


/**
 *  会话输入状态变更
 * userInfo{WKConversationTypingStatusInfosKey : @[{WKConversationId : NSString,
 *                                                  WKConversationTypingTypeKey : NSNumber<WKConversationTypingType>,
 *                                                  WKConversationTypingCommandKey : NSNumber<WKConversationTypingCommand>}]}
 */
FOUNDATION_EXTERN NSString *const WKConversationUpdateTypingStatusNotify __deprecated_msg("using WKConversationTypingStatusUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKConversationTypingStatusInfosKey __deprecated_msg("using WKConversationTypingStatusUserInfoKey instead");


/**
 *  自定义消息推送：userInfo = {WKUserInfoCustomerDataKey : NSArray<WKBizNotice>}
 */
FOUNDATION_EXTERN NSString *const WKReceiveCustomerDataNotify __deprecated_msg("using WKCustomDataReceivedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoCustomerDataKey __deprecated_msg("using WKCustomDataUserInfoKey instead");


/**
 *  消息已读：userInfo = {WKUserInfoMessagesKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKMessagesIsReadNotify __deprecated_msg("using WKMessagesIsReadNotification instead");



/**
 *  网络重连成功：userInfo = {WKUserInfoConversationsKey : NSArray<id<WKBizConversation>>, WKUserInfoMessagesKey : NSArray<id<WKBizMessage>>}
 */
FOUNDATION_EXTERN NSString *const WKReconnectedNotify __deprecated_msg("using WKReconnectedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoConversationsKey __deprecated_msg("using WKConversationsUserInfoKey instead");

/**
 *  云设置更新：userInfo = {WKCloudSettingArrayKey : NSArray<WKCloudSetting>}
 */
FOUNDATION_EXTERN NSString *const WKCloudSettingNotify __deprecated_msg("using WKCloudSettingUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKCloudSettingArrayKey __deprecated_msg("using WKCloudSettingsUserInfoKey instead");


/**
 *  消息已读：userInfo = {WKUserInfoProfileKey : id<WKUserProtocol>, WKUserInfoOpenIdKey : NSNumber<int64_t>}
 *  可以忽略WKUserInfoOpenIdKey，openId可以从WKUserProtocol获取
 */
FOUNDATION_EXTERN NSString *const WKUserUpdatedNotify __deprecated_msg("using WKProfileUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKUserInfoProfileKey __deprecated_msg("using WKProfileUserInfoKey instead");
FOUNDATION_EXTERN NSString *const WKUserInfoOpenIdKey __deprecated_msg("you can get openId from object of WKProfileUserInfoKey");


/**
 *  终端在线状态：userInfo = {WKDeviceStatusInfoKey : WKDeviceStatus}
 */
FOUNDATION_EXTERN NSString *const WKDeviceStatusNotify __deprecated_msg("using WKDeviceStatusUpdatedNotification instead");
FOUNDATION_EXTERN NSString *const WKDeviceStatusInfoKey __deprecated_msg("using WKDeviceStatusUserInfoKey instead");


/**
 *  登录成功：用户相关的初始化可以放这里
 */
FOUNDATION_EXTERN NSString *const WKAuthLoginOKNotification __deprecated_msg("using WKLoginFinishedNotification instead");

/**
 *  登出成功：用户相关的清理可以放这里
 */
FOUNDATION_EXTERN NSString *const WKAuthLogoutOKNotification __deprecated_msg("using WKLogoutFinishedNotification instead");
