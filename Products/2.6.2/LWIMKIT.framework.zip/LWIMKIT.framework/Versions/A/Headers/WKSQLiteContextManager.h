//
//  WKSQLiteContextManager.h
//  LWIMKitExample
//
//  Created by Lings on 14-8-14.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LWSQLiteContext.h"
@class OpenDatabase;
@interface WKSQLiteContextManager : NSObject <LWSQLiteContextDelegate>

// 当前用户对应数据库的context, 不要保存，当前用户变更会变的
+ (instancetype)sharedManager;

- (void)setCurrentContext:(LWSQLiteContext *)context;
- (void)setCurrentContextWithDatabase:(OpenDatabase *)odb;

- (LWSQLiteContext *)currentContext;

@end
