//
//  WKCloudSetting.h
//  LWIMKitExample
//
//  Created by 申达 on 15/1/26.
//  Copyright (c) 2015年 Alibaba. All rights reserved.
//

#ifndef LWIMKitExample_WKCloudSetting_h
#define LWIMKitExample_WKCloudSetting_h

#import <Foundation/Foundation.h>

@interface WKCloudSetting : NSObject

/**
 *  3rd应用的模块名称(一些保留值不能使用，比如wk_im, wk_user)
 */
@property(nonatomic, copy) NSString*     moduleName;

/**
 *  3rd用户的设置项的key值
 */
@property(nonatomic, copy) NSString*     key;

/**
 *  3rd用户的设置项的value值
 */
@property(nonatomic, copy) NSString*     settingValue;

/**
 *  设置项生效范围, 1代表客户端生效, 2代表服务端生效, 0代码全部生效
 */
@property(nonatomic, strong) NSNumber*   effectScope;

@end

#endif
