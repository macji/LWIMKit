//
//  WKAudioRecordUtils.h
//  LWIMKitExample
//
//  Created by 阳翼 on 14-12-16.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LWFileResultValue.h"

@interface WKAudioUploadManager : NSObject

/**
 * 获取语音上传管理器实例
 */
+ (instancetype)sharedAudioUploadManager;

/**
 * 【边录边传】开始上传操作
 */
- (void)startUploadAudioFileByFragmentsWithPath:(NSString *)audioFilePath;

/**
 * 一块块上传文件
 */
- (void)uploadAudioFileByFragments;

/**
 * 取消【边录边传】的上传操作
 */
- (void)cancelUploadAudioFileByFragments;

/**
 * 完成【边录边传】的上传操作
 */
- (void)finishUploadAudioFileByFragmentsCompleteBlock:(void (^)(LWFileResultValue *fileResult, NSError *err))completeBlock;

@end
