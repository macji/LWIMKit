//
//  WKCloudSettingServiceProtocol.h
//  LWIMKitExample
//
//  Created by 香象 on 24/11/14.
//  Copyright (c) 2014 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WKCloudSetting.h"


@protocol IMError;
@protocol WKInternalCloudSettingServiceProtocol;

@protocol WKCloudSettingServiceProtocol <NSObject>

/**
 * 更新云设置 (仅限第三方业务设置，不支持以wk_开头的module或者key)
 * @param cloudSetting: WKCloudSetting对象
 * @param successBlock: 成功后调用
 * @param failureBlock: 失败后调用
 */
- (void)updateCloudSettings:(WKCloudSetting *)cloudSetting
               successBlock:(void (^)())successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 * 通过key从database中搜索WKCloudSetting对象
 * @param module: WKCloudSetting的module
 * @param key: WKCloudSetting的key
 * @return: 如果有对应的记录，则返回WKCloudSetting实例，否则返回nil
 */
- (WKCloudSetting*)cloudSettingForModule:(NSString*)module key:(NSString*)key;

/**
 * 设置是否开启XPN（默认开启）
 * @param enabled: 是否开启
 * @param successBlock: 成功后调用
 * @param failureBlock: 失败后调用
 */
- (void)setXPNEnabled:(BOOL)enabled successBlock:(void (^)())successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 * 是否已开启XPN（数据来自本地DB缓存）
 * @return: YES为开启，NO为关闭
 */
- (BOOL)isXPNEnabled;

/**
 * 设置XPN消息是否显示详情（默认显示）
 * @param showDetail: xpn消息是否显示详情
 * @param successBlock: 成功后调用
 * @param failureBlock: 失败后调用
 */
- (void)setXPNShowDetail:(BOOL)showDetail successBlock:(void (^)())successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 * XPN是否显示详情（数据来自本地DB缓存）
 * @return: YES为显示，NO为不显示
 */
- (BOOL)isXPNShowDetail;

/**
 * 设置语言类型
 * @param locale: 语言类型
 * @param successBlock: 成功后调用
 * @param failureBlock: 失败后调用
 */
- (void)setLocale:(NSString*)locale successBlock:(void (^)())successBlock
     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 * 返回当前语言类型（数据来自本地DB缓存）
 * @return: current locale
 */
- (NSString*)getLocale;

@end


