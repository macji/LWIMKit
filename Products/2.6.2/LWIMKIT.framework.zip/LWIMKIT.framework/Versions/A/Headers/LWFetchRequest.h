//
//  LWFetchRequest.h
//  SQLiteHookDemo
//
//  Created by Lings on 14-6-4.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LWFetchRequest : NSObject

@property (nonatomic, strong, readonly) Class entityClazz;
@property (nonatomic, copy, readonly) NSString *shardingId;

@property (nonatomic, copy) NSArray * sortDescriptors; // <NSSortDescriptor *>
@property (nonatomic, copy) NSString * sqlWhereStatement; // eg. "userId = 8888"
@property (nonatomic, assign) NSUInteger fetchLimit; // 0表示不限制

- (id)initWithEntityClazz:(Class)entityClazz;
- (id)initWithEntityClazz:(Class)entityClazz shardingId:(NSString *)shardingId;

@end