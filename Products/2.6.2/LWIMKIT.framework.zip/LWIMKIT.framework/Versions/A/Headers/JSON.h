//
//  JSON.h
//  OCJSON
//
//  Created by zhiwen.mizw on 8/15/14.
//  Copyright (c) 2014 zhiwen.mizw. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONCollectionType.h"
#import "JSONSerializer.h"

@interface JSON : NSObject

#pragma mark - toJSONString

/**
 *  将对象转在JSON字符串；
 *
 *  目前支持的类型：
 *  类：
 *      所有的基本类型(NSString、float、NSInteger...)
 *      集合类型(NSArray、NSDictionary、NSSet、NSOrderedSet...)
 *      复合类型(NSData)
 *      时间类型(NSDate)
 *  结构体：
 *      CGPoint CGRect CGSize CGAffineTransform UIEdgeInsets UIOffset
 *      (自定义结构体，不支持JSON转换；也不支持扩展)
 *
 *  自定义类型：
 *      支持用户可以定义任意的类，且类属性为以上所支持的类型都可以支持
 *
 *  (如果以上类型不能满足需求、可以扩展转换器来实现JSON转换)
 *  1、扩展JSON转换器；实现 JSONSerializer 协议，实现协议里的方法；
 *  2、注册JSON转换器；调用 JSONConfig 中的 registerSerializer 函数进行注册
 *
 *  @param value 一个对象实例
 *
 *  @return JSON格式的字符串数据
 */
+ (NSString *)toJSONString:(id)value;

/**
 *  将对象转在JSON字符串；
 *
 *  @param value       value 一个对象实例
 *  @param fieldFilter
 *          属性过滤器；@value 对象中的某个属性不希望被转成JSON，那么可以实现此block进行过滤；
 *          另外同时也可以按类型来过滤，比如不希望NSValue被转JSON
 *
 *  @param valueFitler
 *          值过滤器；@value 对象中某些值为隐私数据，需要加*处理；则可以通过它来实现
 *
 *  @return JSON格式的字符串数据
 */
+ (NSString *)toJSONString:(id)value
           withFieldFilter:(JSONClassFieldFilter)fieldFilter
            andValueFitler:(JSONValueFilter)valueFitler
                  features:(JSONSerializerFeature)features;

+ (NSString *)toJSONString:(id)value withFieldNameFilter:(JSONClassFieldFilter)fieldFilter;

+ (NSString *)toJSONString:(id)value withValueFilter:(JSONValueFilter)valueFitler;

+ (NSString *)toJSONString:(id)value features:(JSONSerializerFeature)features;

////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
#pragma mark - parserJSON
/**
 * 解析json字符串，并将解析好的json对象序列化成指定的类型
 *
 * 注意：如果Class里面有NSArray,NSDictionary 类型的属性，且里面存放着自定义类型对象时需要实现
 * JSONCollectionType ，通过实现里面的函数告知NSArray里面的类型
 *
 */
+ (id)parserObject:(NSString *)jsonString clazz:(Class)clazz;

+ (id)parserObject:(NSString *)jsonString;
/**
 *  JSON 格式的数组解析成指定的类型列表
 *
 *  @param jsonString JSON格式的字符串，必须以[ 打头，]结尾
 *  @param clazz      指定数组元素类型
 *
 *  @return 转换结果；为指定类型的对象列表
 */
+ (NSArray *)parserArray:(NSString *)jsonString clazz:(Class)clazz;

/**
 *  JSON
 *字符串数组，转成数组对象；使用场景，一个JSON数组的字符串，在未知类型的时候可以通过此方法转换；主要对JSONSerializerFeature
 *的JSON_WRITE_CLASSNAME支持
 *
 *  @param jsonString JSON数组字符串[xxxx,xxx]
 *
 *  @return NSArray
 */
+ (NSArray *)parserArray:(NSString *)jsonString;

/**
 *  JSON 格式的字符串解析成JSONObject, 也就是Dictionary
 *
 *  @param jsonString JSON字符串
 *
 *  @return 转换结果；Dictionary 对象，里面包含了所有数据的值
 */
+ (id)parser:(NSString *)jsonString;

@end
