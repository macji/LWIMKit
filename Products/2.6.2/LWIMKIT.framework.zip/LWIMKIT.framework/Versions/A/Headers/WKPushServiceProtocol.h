//
//  WKPushServiceProtocol.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-9-9.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WKNoticeHandlerProtocol;

@protocol WKPushServiceProtocol<NSObject>

/**
 *  添加监听通知
 *
 *  @param topic    注册通知 uri
 *  @param handler      接受通知的handler
 */
- (void)registerNoticeHandler:(id<WKNoticeHandlerProtocol>)handler forTopic:(NSString *)topic;

/**
 *  移除监听通知
 *
 *  @param topicName   要移除监听的topic
 */
- (void)removeTopic:(NSString *)topicName;

@end
