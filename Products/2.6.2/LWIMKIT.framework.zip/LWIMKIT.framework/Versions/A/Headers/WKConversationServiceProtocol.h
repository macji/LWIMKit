//
//  WKConversationServiceProtocol.h
//  LWIMKitExample
//
//  Created by 香象 on 28/8/14.
//  Copyright (c) 2014 Alibaba. All rights reserved.
//
//  Modify by huichen.xyh on 2014-09-05 添加注释
//

#import <Foundation/Foundation.h>
#import "WKBizConversationModel.h"


@protocol WKConversationInternalServiceProtocol;
@protocol WKBizConversation,WKBizMessage;
@protocol IMError;

/**
 *  会话相关的接口定义，其中包含群组会话
 */
@protocol WKConversationServiceProtocol<NSObject>

@required

/**
 *  仅供内部使用私有API
 */
- (id<WKConversationInternalServiceProtocol>)internalConversationService;

#pragma mark 加载会话

/**
 *  通过conversationId获取一个会话，不触发网络请求，从本地缓存取值
 *  @param conversationId会话Id
 *  @return 会话
 */
- (id<WKBizConversation>)conversationWithConversationId:(NSString *)conversationId;

/**
 *  获取缓存中批量的conversations
 *  @param sortDescriptors 排序字段 对象NSSortDescriptor，字段参考@see WKBizConversation
 *  @param offset          数据集开始
 *  @param limit           返回数据集大小
 *  @return WKBizConversation数据集
 */
- (NSArray *)conversationsWithSortDescriptors:(NSArray *)sortDescriptors offset:(NSUInteger)offset limit:(NSUInteger)count;

/**
 *  获取缓存中批量的conversations
 *  @param sortDescriptors 排序字段 对象NSSortDescriptor，字段参考@see WKBizConversation
 *  @param limit           返回数据集大小
 *  @param statuses        会话状态数组
 *  @return WKBizConversation数据集
 */
- (NSArray *)conversationsWithSortDescriptors:(NSArray *)sortDescriptors statuses:(NSArray *)statuses offset:(NSUInteger)offset limit:(NSUInteger)limit;


/**
 *  获取最近的count个会话，内部有数据缓存，如果本地数据已经有count个，则直接返回，若不够则发起网络请求
 *
 *  @param count       获取数量，当传入0时表示获取所有的会话；最大值为1000，若设置超过最大值，以最大值返回
 *  @param type        需要获取的会话类型，各类型支持组合WKConversationTypeMTM|WKConversationTypeOTO，
 *  @param successBlock 成功回调
 *      @param conversations 符合条件的会话列表，array of WKBizConversation @see WKBizConversation
 结果排序按照sortIndex与latestModifiedAt排序。
 *  @param failureBlock 失败回调
 *      @param error            失败的错误信息
 */
- (void)loadLatestConversationsWithCount:(int)count
                                    type:(NSUInteger)type
                            successBlock:(void (^)(NSArray *conversations))successBlock
                            failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取所加入的所有群聊
 *
 *  @param successBlock 成功回调
 *      @param conversations 符合条件的会话列表，array of LIMBizConversation @see LIMBizConversation
 *  @param failureBlock 失败回调
 *      @param error            失败的错误信息
 */
- (void)loadGroupConversationsWithSuccessBlock:(void (^)(NSArray *conversations))successBlock
                                  failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取会话信息，本地有数据直接返回
 *
 *  @param conversationId   要获取的会话id
 *  @param successBlock     成功回调
 *      @param conversation 获取成功的会话对象
 *  @param failureBlock 失败回调
 *      @param error        失败的错误信息
 */
- (void)loadConversation:(NSString *)conversationId
            successBlock:(void (^)(id<WKBizConversation> conversation))successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;


#pragma mark 创建会话

/**
 *  创建单聊会话对象，如果本地DB中有直接返回DB中的记录，如果没有，创建一个标记为删除状态的会话对象
 *
 *  @param openId     对方的openId，不能为空也不能传入登录者自己的openId
 *  @param title      会话标题
 *  @param isSpecialized      特别与否，会生成不同的两个单聊，通常情况下，用户置为NO
 *  @param icon       会话icon
 *
 *  @return WKBizConversation会话对象 @see WKBizConversation
 */
- (id<WKBizConversation> )createSingleConversationWithOtherOpenId:(int64_t)openId
                                                            title:(NSString *)title
                                                    isSpecialized:(BOOL)isSpecialized
                                                             icon:(NSString *)icon;

/**
 *  创建单聊会话对象，如果本地DB中有直接返回DB中的记录，如果没有，创建一个标记为删除状态的会话对象
 *
 *  @param openId     对方的openId，不能为空也不能传入登录者自己的openId
 *  @param title      会话标题，可以传入nil
 *  @param icon       会话icon，可以传入nil
 *
 *  @return WKBizConversation会话对象 @see WKBizConversation
 */
- (id<WKBizConversation>)createSingleConversationWithOtherOpenId:(int64_t)openId
                                                           title:(NSString *)title
                                                            icon:(NSString *)icon;

/**
 *  创建群聊会话，包括自己openId在内，成员个数至少两人
 *
 *  @param openIds      将要拉入此群的成员的openId，NSArray<NSNumber<int64_t>>，openIds可以包含自己的openId，也可以不包含，创建的群都会包含自己。要成功创建群成员，必须保证群成员个数不少于两人。
 memberIds中可以包含自己的openId，也可以不包含
 *  @param title        会话标题，可以传入nil
 *  @param icon         会话icon，可以传入nil
 *  @param message      创建会话要显示的系统提示文案，若不需要可以传入nil
 *  @param successBlock 成功回调
 *      @param WKBizConversation 创建成功返回的会话对象
 *  @param failureBlock 失败回调
 *      @param error        失败的错误信息
 */
- (void)createGroupWithOpenIds:(NSArray *)openIds
                         title:(NSString *)title
                          icon:(NSString *)icon
                       message:(id<WKBizMessage>)message
                  successBlock:(void (^)(id<WKBizConversation> conversation))successBlock
                  failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  创建群聊会话，包括自己openId在内，成员个数至少两人
 *
 *  @param openIds      将要拉入此群的成员的openId，NSArray<NSNumber<int64_t>>，openIds可以包含自己的openId，也可以不包含，创建的群都会包含自己。要成功创建群成员，必须保证群成员个数不少于两人。
 *  @param title        会话标题
 *  @param icon         会话icon
 *  @param message      创建会话要显示的系统提示文案，若不需要可以传入nil
 *  @param tag          业务表示
 *  @param extension    业务拓展
 *  @param successBlock 成功回调
 *      @param WKBizConversation 创建成功返回的会话对象
 *  @param failureBlock 失败回调
 *      @param error        失败的错误信息
 */
- (void)createGroupWithOpenIds:(NSArray *)openIds
                         title:(NSString *)title
                          icon:(NSString *)icon
                           tag:(NSInteger)tag
                     extension:(NSDictionary *)extension
                       message:(id<WKBizMessage>)message
                  successBlock:(void (^)(id<WKBizConversation> conversation))successBlock
                  failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  创建群聊会话，包括自己openId在内，成员个数至少两人
 *
 *  @param openIds      将要拉入此群的成员的openId，NSArray<NSNumber<int64_t>>，openIds可以包含自己的openId，也可以不包含，创建的群都会包含自己。要成功创建群成员，必须保证群成员个数不少于两人。
 *  @param title        会话标题
 *  @param icon         会话icon
 *  @param message      创建会话要显示的系统提示文案，若不需要可以传入nil
 *  @param tag          业务表示
 *  @param memberLimit  最大成员数量限制
 *  @param groupLevel   0非大群，1大群，其他数字可做大群等级扩展使用
 *  @param extension    业务拓展
 *  @param successBlock 成功回调
 *      @param WKBizConversation 创建成功返回的会话对象
 *  @param failureBlock 失败回调
 *      @param error        失败的错误信息
 */
- (void)createGroupWithOpenIds:(NSArray *)openIds
                         title:(NSString *)title
                          icon:(NSString *)icon
                           tag:(int)tag
                   memberLimit:(int)memberLimit
                    groupLevel:(int)groupLevel
                     extension:(NSDictionary *)extension
                       message:(id<WKBizMessage>)message
                  successBlock:(void (^)(id<WKBizConversation> conversation))successBlock
                  failureBlock:(void (^)(id<IMError> error))failureBlock;

#pragma mark - 隐藏会话

/**
 *  删除会话(逻辑删除：设置为不可见)
 *
 *  @param conversationId  会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)removeConversation:(NSString *)conversationId
              successBlock:(void (^)(void))successBlock
              failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  批量删除会话
 *
 *  @param conversationIds   会话id列表，array of NSString
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)removeConversations:(NSArray *)conversationIds
               successBlock:(void (^)(void))successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  删除会话(删除会话及清除所属的消息)
 *
 *  @param conversationId  会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)removeAndClearConversation:(NSString *)conversationId
                      successBlock:(void (^)(void))successBlock
                      failureBlock:(void (^)(id<IMError> error))failureBlock;
/**
 *  清除会话中的所有消息
 *
 *  @param conversationId   需要清除消息的会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)clearConversation:(NSString *)conversationId
             successBlock:(void (^)(void))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock;

#pragma mark 会话成员管理

/**
 *  增加群会话成员
 *
 *  @param members      添加的新成员id列表，array<number<int64>> 用户openid
 *  @param conversationId  群组会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)addMembers:(NSArray *)members
           toGroup:(NSString *)conversationId
           message:(id<WKBizMessage>)message
      successBlock:(void (^)(void))successBlock
      failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  移除群会话成员
 *
 *  @param members      移除的成员id列表，array<number<int64>> 用户openid
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)removeMembers:(NSArray *)members
            fromGroup:(NSString *)conversationId
              message:(id<WKBizMessage>)message
         successBlock:(void (^)(void))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  移除群会话成员
 *
 *  @param members      移除的成员id列表，array<number<int64>> 用户openid
 *  @param conversationId          会话id
 *  @param receivers    消息接收者的id列表，array<number<int64>> 用户openid, 如果为nil则发给所有群成员
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)removeMembers:(NSArray *)members
            fromGroup:(NSString *)conversationId
              message:(id<WKBizMessage>)message
            receivers:(NSArray *)receivers
         successBlock:(void (^)(void))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取会话中的成员列表
 *
 *  @param conversationId          群会话id
 *  @param offset       查询偏移量
 *  @param size         查询大小
 *  @param successBlock 成功回调
 *      @param memberList   成员列表，array<WKMember>
 *  @param failureBlock 失败回调
 *      @param error        失败的错误信息
 */
- (void)membersOfGroup:(NSString *)conversationId
                offset:(long)offset
                  size:(int)size
          successBlock:(void (^)(NSArray *memberList))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新会话成员最大数量限制
 *
 *  @param limit            群成员最大数量限制
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateMemberLimit:(int)limit
           ofConversation:(NSString *)conversationId
             successBlock:(void (^)(void))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新会话是否为大群
 *
 *  @param groupLevel       0非大群，1大群，其他数字可做大群等级扩展使用
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateGroupLevel:(int)groupLevel
          ofConversation:(NSString *)conversationId
            successBlock:(void (^)(void))successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  退出群聊
 *
 *  @param conversationId           群会话id
 *  @param message                  退群的系统消息
 *  @param successBlock             成功回调
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 */
- (void)quitGroup:(NSString *)conversationId
          message:(id<WKBizMessage>)message
     successBlock:(void (^)(void))successBlock
     failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  退出群聊, 只通知群主
 *
 *  @param conversationId           群会话id
 *  @param message                  退群的系统消息
 *  @param successBlock             成功回调
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 */
- (void)quitGroupQuiet:(NSString *)conversationId
               message:(id<WKBizMessage>)message
          successBlock:(void (^)(void))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  标记已经离开此群，只有当你确定收到WKConversationStatusKicked后，调用此接口
 *
 *  @param conversationId  群会话ID
 *  @return 表示此次操作成功
 */
- (BOOL)markQuitedTheGroup:(NSString *)conversationId;


/**
 *  解散群
 *
 *  @param conversationId           群会话id
 *  @param successBlock             成功回调
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 **/
- (void)disbandGroup:(NSString *)conversationId
        successBlock:(void (^)(void))successBlock
        failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新群主
 *
 *  @param openId                   新群主的openId
 *  @param conversationId           群会话id
 *  @param message                  发出的系统提示消息
 *  @param successBlock             成功回调
 *      @param conversation 获取成功的会话对象
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 **/
- (void)updateOwner:(int64_t)openId
            ofGroup:(NSString *)conversationId
            message:(id<WKBizMessage>)message
       successBlock:(void (^)(id<WKBizConversation> conversation))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;

#pragma mark 未读数相关

/**
 *  未读消息数量
 *
 *  @return 会话中未读消息数量
 */
- (NSUInteger)allUnreadMessagesCount;


/**
 *  @我的未读消息数量
 *
 *  @return 所有会话中@我的未读消息数量
 */
- (NSUInteger)allUnreadAtMeMessagesCount;


/**
 *  清零所有未读消息数
 *
 *  @return 操作是否成功
 */
- (BOOL)resetAllUnreadMessagesCount;

#pragma mark 会话属性管理

/**
 *  更新会话标题
 *
 *  @param title        新标题
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateTitle:(NSString *)title
     ofConversation:(NSString *)conversationId
            message:(id<WKBizMessage>)message
       successBlock:(void (^)(void))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新会话图标
 *
 *  @param icon         图标
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateIcon:(NSString *)icon
    ofConversation:(NSString *)conversationId
           message:(id<WKBizMessage>)message
      successBlock:(void (^)(void))successBlock
      failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新会话草稿
 *
 *  @param draft         草稿内容
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateDraft:(NSString *)draft
     ofConversation:(NSString *)conversationId
            message:(id<WKBizMessage>)message
       successBlock:(void (^)(void))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新会话草稿
 *
 *  @param draft         草稿内容
 *  @param atList        草稿内容 中的@人列表，key:NSNumber<openId>==>value:NSString<name>
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateDraft:(NSString *)draft
             atList:(NSDictionary *)atList
     ofConversation:(NSString *)conversationId
       successBlock:(void (^)(void))successBlock
       failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  配置会话是否接受消息通知
 *
 *  @param enable       是否开启消息通知的状态
 *  @param conversationId          会话ID
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 */
- (void)updateNotification:(BOOL)enable
            ofConversation:(NSString *)conversationId
              successBlock:(void (^)(void))successBlock
              failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新会话的消息通知提示音
 *
 *  @param sound            提示音的key，需要在服务端做好配置，主要用于APNs
 *  @param conversationId   涉及到的会话Id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateNotificationSound:(NSString *)sound
                 ofConversation:(NSString *)conversationId
                   successBlock:(void (^)(void))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  给单聊的接收方发送正在输入状态的信息
 *
 *  @param conversationId 会话id
 *  @param type           输入类型 @see WKConversationTypingType
 *  @param command        输入命令 @see WKConversationTypingCommand
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateTypingStatusOfConversation:(NSString *)conversationId
                                withType:(WKConversationTypingType)type
                              andCommand:(WKConversationTypingCommand)command
                            successBlock:(void (^)(void))successBlock
                            failureBlock:(void (^)(id<IMError> error))failureBlock;



/**
 *  设置会话为激活状态，当用户进入此会话是需要设置的状态
 *  @param conversationId       是否开启消息通知的状态
 */
- (void)setConversationToActive:(NSString *)conversationId;


/**
 *  更新会话tag，业务方可以用tag做特殊业务标记
 *
 *  @param tag       会话tag值
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateTag:(NSInteger)tag
   ofConversation:(NSString *)conversationId
     successBlock:(void (^)(void))successBlock
     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新会话tag，业务方可以用tag做特殊业务标记
 *
 *  @param tag       会话tag值
 *  @param extension 业务其他标示
 *  @param conversationId          会话id
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)updateTag:(NSInteger)tag
        extension:(NSDictionary *)extension
   ofConversation:(NSString *)conversationId
     successBlock:(void (^)(void))successBlock
     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新群添加成员的权限配置
 *
 *  @param permission       添加群成员的权限 @see WKConversationAddMemberPermission
 *  @param conversationId   会话id
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateAddMemberPermission:(WKConversationAddMemberPermission)permission
                   ofConversation:(NSString *)conversationId
                     successBlock:(void (^)(void))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  将会话置顶， 会影响sort属性
 *
 *  @param conversationId          会话id
 *  @param isTop       是否置顶
 *  @param successBlock 成功回调
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)setTopConversation:(NSString *)cid
                     isTop:(bool)isTop
              successBlock:(void (^)(NSNumber  *topValue))successBlock
              failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  设置最大会话拉取数量
 *  @param maxCount: 最大会话拉取数量
 */
- (void)setConversationMaxCount:(int)maxCount;


#pragma mark 二维码相关

/**
 *  根据conversionId生成群二维码
 *  @param conversionId 群会话id
 *  @param successBlock 成功回调
 *      @param qrCode   二维码字符串
 *      @param expDate   有效日期(单位秒)
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)getQRCodeWithConversionId:(NSString*)conversionId
                     successBlock:(void (^)(NSString *qrCode, int64_t expDate))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  校验群二维码
 *  @param qrCode   二维码字符串
 *  @param successBlock 成功回调
 *      @param senderId 二维码发布者openId
 *      @param conversation 群会话对象
 *      @param isMember 扫码者是否为该群成员
 *  @param failureBlock 失败回调
 *      @param error    失败的错误信息
 */
- (void)verifyQRCode:(NSString*)qrCode
        successBlock:(void (^)(int64_t senderId, id<WKBizConversation> conversation, BOOL isMember))successBlock
        failureBlock:(void (^)(id<IMError> error))failureBlock;

#pragma mark 保存会话

/**
 *  保存会话到db
 *
 *  @param conversation 会话对象
 *
 *  @return 保存是否成功
 */
- (BOOL)saveLocalConversation:(id<WKBizConversation>)conversation;

@end
