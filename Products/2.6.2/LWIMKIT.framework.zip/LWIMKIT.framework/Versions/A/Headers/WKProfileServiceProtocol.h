//
//  WKProfileServiceProtocol.h
//  LWIMKitExample
//
//  Created by 阳翼 on 6/11/14.
//  Copyright (c) 2014 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WKUserProtocol, IMError, WKProfileSyncProtocol, WKInternalProfileServiceProtocol;

@protocol WKProfileServiceProtocol <NSObject>

@property (nonatomic, assign) BOOL profileModuleEnabled;

- (id<WKProfileSyncProtocol>) internalSyncProtocol;

- (id<WKInternalProfileServiceProtocol>) internalProtocol;

/**
 *  获取最新的个人资料模型
 *
 *  @param openId      openId{int64_t}必须大于零
 *
 *  @return 返回满足WKUserProtocol的对象
 */
- (id<WKUserProtocol>)latestUserProfileByOpenId:(int64_t)openId;

/**
 *  获取个人资料模型，只要openid合理，一定返回实例。本地有若有新的数据，立即返回，将去远程获取
 *  获取到后将会post WKUserUpdatedNotification通知
 *
 *  @param openId      openId{int64_t}必须大于零
 *  @param version     数据的版本{long}，若传入0则取缓存，若大于0，则比较远程和缓存的version来决定是否去服务器获取
 *
 *  @return 返回满足WKUserProtocol的对象，可能返回nil
 */
- (id<WKUserProtocol>)userProfileByOpenId:(int64_t)openId
                                  version:(long)version;


/**
 *  从本地db获取个人资料模型.
 *
 *  @param openId      openId{int64_t}必须大于零
 *
 *  @return 返回满足WKUserProtocol的对象，可能返回nil
 */

- (id<WKUserProtocol>)loadLocalUserProfileByOpenId:(int64_t)openId;

/**
 *  从本地db获取个人资料模型.
 *
 *  @param openIds      openId的数组
 *
 *  @return 返回WKUserProtocol的数组，可能返回nil
 */

- (NSArray *)loadLocalUserProfilesByOpenIds:(NSArray *) openIds;

/**
 *  获取个人资料模型，内部缓存有数据则直接返回，没数据会走rpc
 *
 *  @param openId      openId
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料模型
 *  @param failureBlock 失败回调
 *      @param error 失败的错误信息
 */
- (void)loadUserProfileByOpenId:(int64_t) openId
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料模型，内部有数据缓存
 *
 *  @param mobile       手机号码
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料模型
 *  @param failureBlock 失败回调
 *      @param error 失败的错误信息
 */
- (void)loadUserProfileByMobile:(NSString *)mobile
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取个人资料模型，内部有数据缓存
 *
 *  @param mobile       手机号码
 *  @param countryCode  国家码（号码地区限定），传入nil默认为+86
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料模型
 *  @param failureBlock 失败回调
 *      @param error 失败的错误信息
 */
- (void)loadUserProfileByMobile:(NSString *)mobile
                    countryCode:(NSString *)countryCode
                   successBlock:(void (^)(id<WKUserProtocol> bizProfile))successBlock
                   failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  获取个人资料模型，内部有数据缓存
 *
 *  @param openIds       openId的数组
 *  @param successBlock 成功回调
 *      @param bizProfile 获取到的个人资料模型
 *  @param failureBlock 失败回调
 *      @param error 失败的错误信息
 */
- (void)loadUserProfilesByOpenIds:(NSArray *)openIds
                     successBlock:(void (^)(NSArray *list))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料模型，内部有数据缓存
 *
 *  @param mobiles          手机号码数组
 *  @param isCreateNew      如果没有该用户，是否需要新建用户
 *  @param successBlock     成功回调
 *      @param bizProfile   获取到的个人资料模型
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)loadUserProfilesByMobiles:(NSArray *) mobiles
                      isCreateNew:(bool)isCreateNew
                     successBlock:(void (^)(NSArray *list))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  获取个人资料模型，只返回本地数据
 *
 *  @param mobiles          手机号码数组
 *  @param countryCode      国家码（号码地区限定），传入nil默认为+86
 *  @return NSArray @see id<WKUserProtocol>
 */
- (NSArray *)userProfilesByMobiles:(NSArray *) mobiles countryCode:(NSString *)countryCode;


/**
 *  更新个人资料模型，成功后更新到缓存
 *
 *  @param userProfile      用来更新的资料模型
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateUserProfile:(id<WKUserProtocol>) userProfile
             successBlock:(void (^)(void))successBlock
             failureBlock:(void (^)(id<IMError> error))failureBlock __attribute((deprecated));


/**
 *  更新个人资料模型
 *
 *  @param userProfile          用来上传的新的资料模型(avatar字段支持本地路径和远程地址；profile中的字段为空则不会更新该字段)
 *  @param successBlock         成功回调
 *      @param user             更新后的个人资料
 *  @param failureBlock         失败回调
 *      @param error            失败的错误信息
 */
- (void)updateProfile:(id<WKUserProtocol>) userProfile
         successBlock:(void (^)(id<WKUserProtocol> user))successBlock
         failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  更新本人昵称
 *
 *  @param newNickname      要更新的昵称
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateMyNickname:(NSString *) newNickname
            successBlock:(void (^)(void))successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像，成功后也更新到缓存
 *
 *  @param uri              要更新的头像(支持本地路径和远程地址)
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateMyAvatar:(NSString *) uri
          successBlock:(void (^)(void))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock __attribute((deprecated));


/**
 *  更新本人头像
 *
 *  @param uri              要更新的头像(支持本地路径和远程地址)
 *  @param successBlock     成功回调
 *      @param url          更新后的头像地址
 *  @param failureBlock     失败回调
 *      @param error        失败的错误信息
 */
- (void)updateAvatarWithUri:(NSString *) uri
               successBlock:(void (^)(NSString *url))successBlock
               failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像
 *
 *  @param image                    要更新的头像（JPEG格式）
 *  @param compressionQuality       上传图片时的压缩比（1为最大压缩，0为最少压缩）
 *  @param successBlock             成功回调
 *      @param url                  更新后的头像地址
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 */
- (void)updateAvatarWithJPEGImage:(UIImage *)image
               compressionQuality:(CGFloat)compressionQuality
                     successBlock:(void (^)(NSString *url))successBlock
                     failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  更新本人头像
 *
 *  @param image                    要更新的头像（PNG格式）
 *  @param successBlock             成功回调
 *      @param url                  更新后的头像地址
 *  @param failureBlock             失败回调
 *      @param error                失败的错误信息
 */
- (void)updateAvatarWithPNGImage:(UIImage *)image
                    successBlock:(void (^)(NSString *url))successBlock
                    failureBlock:(void (^)(id<IMError> error))failureBlock;

@end