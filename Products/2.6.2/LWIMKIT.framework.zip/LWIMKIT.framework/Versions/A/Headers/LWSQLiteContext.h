//
//  LWSQLiteContext.h
//  SQLiteHookDemo
//
//  Created by Lings on 14-6-4.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "LWSQLiteHook.h"


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#define kLWSQLiteInvalidRowId       kLWSQLiteHookInvalidRowId


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@protocol LWSQLiteContextDelegate;

@interface LWSQLiteContext : NSObject

@property (nonatomic, assign, readonly) sqlite3 *       sqlite;
@property (nonatomic, strong, readonly) LWSQLiteHook *  sqliteHook;

@property (nonatomic, strong) id                        customDatabase; // 注意：这里会对调用方的数据库实例做retain操作
@property (nonatomic, weak) id<LWSQLiteContextDelegate> delegate;

/**
 *  通过传入sqlite3指针来实例化context。<br/>
 *  <b>注意</b>：由于sqlite3指针是一个c指针，无法通过retain的方式来保证其生命周期，所以务必请保证在该sqlite3指针close之前销毁context
 *
 *  @param sqlite               sqlite3指针
 *  @param enableExclusiveHook  是否开启sqlite hook独占，默认：YES
 *
 *  @return LWSQLiteContext实例
 */
+ (instancetype)contextWithSQLite:(sqlite3 *)sqlite;
+ (instancetype)contextWithSQLite:(sqlite3 *)sqlite enableExclusiveHook:(BOOL)enableExclusiveHook;

- (id)initWithSQLite:(sqlite3 *)sqlite;
- (id)initWithSQLite:(sqlite3 *)sqlite enableExclusiveHook:(BOOL)enableExclusiveHook;

/**
 *  依赖delegate实现
 */
- (NSString *)tableNameWithEntityClazz:(Class)clazz shardingId:(NSString *)shardingId;

- (sqlite_int64)rowIdWithEntity:(id)entity;

- (NSArray *)fetchObjectsWithWithSql:(NSString *)sql
                          parameters:(NSArray *)parameters
                         entityClazz:(Class)clazz
                          shardingId:(NSString *)shardingId;

@end


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
@protocol LWSQLiteContextDelegate <NSObject>

@required

- (NSString *)sqliteGetTableNameWithDatabase:(id)database
                                 entityClazz:(Class)clazz
                                  shardingId:(NSString *)shardingId;

- (sqlite_int64)sqliteGetRowIdWithEntity:(id)entity;

- (NSArray *)sqliteFetchObjectsWithSql:(NSString *)sql
                            parameters:(NSArray *)parameters
                              database:(id)database
                           entityClazz:(Class)clazz
                            shardingId:(NSString *)shardingId;

@end
