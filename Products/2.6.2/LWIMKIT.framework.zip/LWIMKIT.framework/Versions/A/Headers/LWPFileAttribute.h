//
//  LWPFileAttribute.h
//  Pods
//
//  Created by guodi.ggd on 8/15/14.
//
//

#import <Foundation/Foundation.h>

@interface LWPFileAttribute : NSObject <NSCopying, NSCoding>
@property (nonatomic, copy) NSString    *filePath;      //和fileData必须传递一个，一般带configFileAttr的接口都帮你设置好了再回调了
@property (nonatomic, copy) NSData      *fileData;      //和filePath必须传递一个，一般带configFileAttr的接口都帮你设置好了再回调了
@property (nonatomic, copy) NSString    *fileName;      //可以不传了

@property (nonatomic, copy) NSString    *mime;          //详见LWPFileKit.h文件里的定义
@property (nonatomic, copy) NSString    *uid;           //可以不传了，因为此后的uid都是在lwp建立时上传了，之后这条连接里的uid会缓存在服务端

@property (nonatomic, copy) NSString    *fext;          //可以不传了，不传使用的是mime的类型后缀


@property (nonatomic, assign) BOOL isPrivate;           //阅后即焚的标记
@property (nonatomic, assign) BOOL isStreaming;         //流式上传的标记
@property (nonatomic, assign) BOOL isOrignal;           //上传原图的标记
@property (nonatomic, assign) BOOL isHD;                //上传高清图的标记
@property (nonatomic, assign) BOOL useMidiaId;          //是否返回media_id

@property (nonatomic, assign) BOOL failOnNetworkBroken; //文件是否在网络断开的情况下使上传失败
@end
