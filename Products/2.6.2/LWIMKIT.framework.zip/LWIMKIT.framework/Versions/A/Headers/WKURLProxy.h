//
//  WKURLProxy.h
//  Laiwang
//
//  Created by 申达 on 15-1-29.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import "WebViewProxy.h"


@interface WKURLProxy : NSObject

/**
 * 仅支持http协议，以host，path组成的正则表达式为拦截条件：如拦截http://m.laiwang.com/market/pc/help/index.php
 * @param host: 域名，必要字段，如：m.laiwang.com
 * @param path: 路径，可以为空，如：/market/pc/help/
 */

+ (void)handleRequest:(NSString*)host path:(NSString*)path;

/**
 * 批量拦截：仅支持http协议，以host，path组成的正则表达式为拦截条件
 * @param array: NSDictionary数组，keys：host & path
 */

+ (void)handleRequests:(NSArray*)array;


/**
 * 自定义正则表达式拦截请求
 * @param predicate: Match on any property of NSURL, e.g. "scheme MATCHES 'http' AND host MATCHES 'www.google.com'"
 */

+ (void)handleRequestsMatching:(NSPredicate *)predicate;

@end
