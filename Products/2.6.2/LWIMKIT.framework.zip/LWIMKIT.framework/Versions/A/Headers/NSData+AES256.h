//
//  NSData+AES256.h
//  LWIMKitExample
//
//  Created by 香象 on 30/12/14.
//  Copyright (c) 2014 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (AES256)

+ (NSData *)AES256EncryptWithWithData:(NSData *)data key:(NSString *)key;

+ (NSData *)AES256DecryptWithData:(NSData *)data key:(NSString *)key;


@end
