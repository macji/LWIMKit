//
//  WKAPNSServiceProtocol.h
//  LWIMKitExample
//
//  Created by 香象 on 28/9/14.
//  Copyright (c) 2014 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol IMError;

/**
 *  针对iOS平台APNS增加的特殊服务。当你注册到平台后，为了能支持后台推送通知，开发者可以调用下面接口来控制。
 */
@protocol WKAPNSServiceProtocol<NSObject>

@required

/**
 *  注册APNS推送接口
 *
 *  @param deviceToken  从苹果服务器上注册设备唯一push token，需要对原始数据去除左右<>符合和中间的空格
 *  @param version      app的版本，version的约定格式，'按照版本号|bundleId|环境'，
 *                      如:'1.0.0|com.laiwang.Dingtalk|release' 或者 '1.0.0|com.laiwang.Dingtalk|debug'
 *                      一般情况下，release用于发布环境的证书，debug用于开发阶段的证书
 *  @param successBlock 发起成功后回调
 *  @param failureBlock 发起失败后回调
 */
- (void)registerDevice:(NSString *)deviceToken
            appVersion:(NSString *)version
          successBlock:(void (^)(void))successBlock
          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  注销APNS推送接口
 *
 *  @param deviceToken  从苹果服务器上注册设备唯一Id
 *  @param successBlock 发起成功后回调
 *  @param failureBlock 发起失败后回调
 */
- (void)unregisterDevice:(NSString *)deviceToken
            successBlock:(void (^)(void))successBlock
            failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  重置ANP的badge数目
 *
 *  @param count        设置的数据
 *  @param successBlock 发起成功后回调
 *  @param failureBlock 发起失败后回调
 */
- (void)syncBadge:(long)count
     successBlock:(void (^)(void))successBlock
     failureBlock:(void (^)(id<IMError> error))failureBlock;

@end
