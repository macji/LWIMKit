//
//  WKBizMessageBuilder.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-10-31.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "WKBizMessageModel.h"
#import "WKAttachment.h"

//PUBLIC

FOUNDATION_EXTERN NSString *const WKLocalMediaIdDomain;//本地mediaId域

@class WKAttachmentImage;
@class WKAttachmentAudio;
@class WKAttachmentCustom;

/**
 * 消息构造器
 */
@interface WKBizMessageBuilder : NSObject

#pragma mark - 普通文本消息
/**
 * 构建普通文本消息
 * @param   text 文本内容
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithText:(NSString *)text;


/**
 * 构建普通文本消息
 * @param   text 文本内容
 * @param   atList 被@的人列表 key:NSNumber<openId> value:NSString<nickname>
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithText:(NSString *)text atList:(NSDictionary *)atList;


/**
 * 根据国际化模板构建系统消息
 * @param   text            文本内容
 * @param   templateId      系统消息的模板id
 * @param   templateData    系统消息的模板数据
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithText:(NSString *)text
                         templateId:(NSString *)templateId
                       templateData:(NSArray *)templateData;

#pragma mark - 图片消息

/**
 * 根据图片附件构建图片消息
 *
 * @param   imageAttachment       图片附件
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImageAttachment:(WKAttachmentImage *)imageAttachment;


/**
 * 构建图片消息（内部将压缩处理图片），接口内部会将原图片文件备份，故调用此函数后，图片可以随意处理
 *
 * @param   imagePath           图片地址(原图)
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImagePath:(NSString *)imagePath;


/**
 * 构建图片消息（内部将压缩处理图片）
 * @param image         图片(原图)
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImage:(UIImage *)image;


/**
 *  构建图片消息（内部将压缩处理图片）
 *
 *  @param image      原图
 *  @param isOriginal 是否上传原图
 *
 *  @return WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImage:(UIImage *)image
                          isOriginal:(BOOL)isOriginal
                           imageSize:(NSUInteger)imageSize;


/**
 * 构建图片消息（内部将压缩处理图片） 推荐使用
 * @param image         图片(原图)
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImageForSend:(UIImage *)image;


#pragma mark - 语音消息

/**
 * 构造语音消息
 * @param audioPath	    音频文件路径
 * @param duration	    音频文件时长(毫秒ms)
 * @param meters	    音频文件音量大小，振幅NSArray<NSNumber<long>>
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithAudioPath:(NSString *)audioPath duration:(int64_t)duration soundMeters:(NSArray *)meters;


/**
 * 构造语音消息
 * @param audioPath	    音频文件路径
 * @param isStream	    是否为“边录边传”语音消息
 * @param duration	    音频文件时长(毫秒ms)
 * @param meters	    音频文件音量大小，振幅NSArray<NSNumber<long>>
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithAudioPath:(NSString *)audioPath withRemoteUrl:(NSString *)url isStream:(BOOL)isStream duration:(int64_t)duration soundMeters:(NSArray *)meters;


#pragma mark - 有声图片消息
/**
 * 构造有声图片消息
 * @param image         图片(原图)
 * @param audioPath	    音频文件路径
 * @param duration	    音频文件时长
 * @param volumns	    音频文件音量大小，振幅NSArray<NSNumber<long>>
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithImage:(UIImage *)image
                           audioPath:(NSString *)audioPath
                            duration:(int64_t)duration
                         soundMeters:(NSArray *)meters;

#pragma mark - 链接（分享）类消息

/**
 *  生成分享类型message
 *
 *  @param linkAttachment           链接类型的附件
 *
 *  @return 消息体
 */
+ (id<WKBizMessage>)messageWithLinkAttachment:(WKAttachmentLink *)linkAttachment;

#pragma mark - 自定义消息构造方法

/**
 * 通过多个自定义附件构造消息
 *
 * @param   type            附件类型(必填)
 * @param   attachments     附件列表(必须为WKAttachmentCustom类型)
 * @param   content         消息展示的内容
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithAttachmentsType:(NSInteger)type
                              customAttchments:(NSArray *)attachments
                                       content:(NSString *)content;


#pragma mark - 其他消息构造方法
/**
 * 构建转发消息, 私有函数, 三方使用会出错
 * @param   message 原消息
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithOriginMessage:(id<WKBizMessage>)message;


#pragma mark - 通用消息构造方法

/**
 * 通过附件构造消息
 *
 * @param   attachment  附件(暂时只支持Audio，Image，File，Link)
 * @return	WKBizMessage对象
 */
+ (id<WKBizMessage>)messageWithAttachment:(WKAttachment*)attachment;


#pragma mark - 自定义附件构造

/**
 * 构造自定义附件（WKAttachmentCustom）
 * @param   attachmentType  附件的附件类型(可选)
 * @param   type            附件的自定义类型(可选)
 * @param   url             附件的url链接(可选)
 * @param   size            附件的大小(可选)
 * @param   extension       附件的扩展字段（字典类型，可选，key/value键值中的value必须为NSString类型）
 * @return  WKAttachmentCustom对象
 */
+ (WKAttachmentCustom *)customAttachmentWithAttachmentType:(NSInteger)attachmentType
                                                customType:(NSInteger)type
                                                       url:(NSString *)url
                                                      size:(int64_t)size
                                                 extension:(NSDictionary *)extension;

#pragma mark - 图片附件构造
/**
 * 构造图片附件
 * @param image         图片(原图)
 * @return	WKAttachmentImage对象
 */
+ (WKAttachmentImage *)imageAttachmentWithImage:(UIImage *)image;

/**
 *  构造图片附件
 *
 *  @param imageSize 原图尺寸
 *
 *  @return
 */
+ (WKAttachmentImage *)imageAttachmentWithImageSize:(UIImage *)image;


/**
 *  构造图片附件(内部接口，不建议使用)
 *
 *  @param image        图片对象
 *  @param isOriginal   是否是原图
 *  @parma imageSize    图片大小
 *  @return
 */

+ (WKAttachmentImage *)imageAttachmentWithImageSize:(UIImage *)image
                                         isOriginal:(BOOL)isOriginal
                                          imageSize:(NSUInteger)imageSize;

/**
 *  构造图片附件(内部接口，不建议使用)
 *
 *  @param image            图片对象
 *  @param isOriginal       是否是原图
 *  @parma imageSize        图片大小
 *  @param orientation      旋转方向
 *  @return
 */

+ (WKAttachmentImage *)imageAttachmentWithImageSize:(UIImage *)image
                                         isOriginal:(BOOL)isOriginal
                                          imageSize:(NSUInteger)imageSize
                                        orientation:(NSInteger)orientation;

/**
 *  生成大图
 *
 *  @param image           原始图片
 *  @param attachmentImage 需要修改attachmentImage
 *  @param message         需要将新的attachmentImage 赋值到message中
 *
 *  @return 返回要发送的图片二进制
 */
+ (NSData *)generateSendImageWithOriginImage:(UIImage *)image
                             imageAttachment:(WKAttachmentImage *)attachmentImage
                                     message:(id<WKBizMessage>)message;

/**
 * 构造图片附件
 * @param imagePath       图片地址(原图)
 * @return	WKAttachmentImage对象
 */
+ (WKAttachmentImage *)imageAttachmentImagePath:(NSString *)imagePath;

#pragma mark - 语音附件构造
/**
 * 构造语音附件
 * @param audioPath	    音频文件路径
 * @param duration	    音频文件时长(毫秒ms)
 * @param meters	    音频文件音量大小，振幅NSArray<NSNumber<long>>
 * @return	WKAttachmentAudio
 */
+ (WKAttachmentAudio *)audioAttachmentWithAudioPath:(NSString *)audioPath duration:(int64_t)duration soundMeters:(NSArray *)meters;


/**
 * 构造语音附件
 * @param audioPath	    音频文件路径
 * @param url           边录边传成功后返回的远程url或mediaId
 * @param isStream      是否边录边传
 * @param duration	    音频文件时长(毫秒ms)
 * @param meters	    音频文件音量大小，振幅NSArray<NSNumber<long>>
 * @return	WKAttachmentAudio
 */
+ (WKAttachmentAudio *)audioAttachmentWithAudioPath:(NSString *)audioPath withRemoteUrl:(NSString *)remoteMediaId isStream:(BOOL)isStream duration:(int64_t)duration soundMeters:(NSArray *)meters;


#pragma mark 构造链接类型附件

+ (WKAttachmentLink *)linkAttachmentWithLink:(NSString *)link
                                        text:(NSString *)text
                                       title:(NSString *)title
                              localImagePath:(NSString *)localImagePath
                                   extension:(NSDictionary *)extension;

+ (WKAttachmentLink *)linkAttachmentWithLink:(NSString *)link
                                        text:(NSString *)text
                                       title:(NSString *)title
                                   imageData:(NSData *)imageData
                                   extension:(NSDictionary *)extension;



/**
 *  构造文件附件
 *
 *  @param path         文件本地路径
 *  @param name         文件名
 *  @param size         文件大小
 *  @parma type         文件类型
 *  @return             WKAttachmentFile对象
 */

+ (WKAttachmentFile *)fileAttachmentWithPath:(NSString *)path name:(NSString *)name size:(NSUInteger)size type:(NSString *)type;


@end
