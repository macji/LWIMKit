//
//  WKMember.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-9-11.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WKUserProtocol;

/**
 *  群成员角色定义
 */
typedef NS_ENUM(NSUInteger, WKConversationMemberRoleType)
{
    /**
     *  未知
     */
    WKConversationNanRole        = 0,
    /**
     * 群主
     */
    WKConversationOwnerRole        = 1,
    /**
     * 管理员
     */
    WKConversationAdminRole         = 2,
    /**
     * 普通成员
     */
    WKConversationNormalRole        = 3,
};


/**
 *  群成员定义
 */
@interface WKMember : NSObject

/**
 *  群成员Profile
 */
@property (nonatomic, strong) id<WKUserProtocol> user;

/**
 *  群成员角色
 */
@property (nonatomic, assign) WKConversationMemberRoleType role;


/**
 *  群成员构造方法
 *  @param openId        群成员的openId和版本 @see WKUserProtocol
 *  @param role          角色定义
 */
+ (instancetype)roleWithOpenId:(id <WKUserProtocol>)openId role:(WKConversationMemberRoleType)role;

@end
