//
//  WKAuthProtocol.h
//  LWIMKitExample
//
//  Created by 香象 on 14-8-19.
//  Copyright (c) 2014年 香象. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  阿里悟空网络状态定义
 */
typedef NS_ENUM(NSUInteger, WKNetworkStatus)
{
    WKNetworkNotReachable               = 1,//<! 没有网络
    WKNetworkReachableVia2G,                //<! 2G
    WKNetworkReachableVia3G,                //<! 3G
    WKNetworkReachableVia3GOr2G,            //<! 2/3G
    WKNetworkReachableVia4G,                //<! 4G
    WKNetworkReachableViaWWAN,              //<! WWAN
    WKNetworkReachableViaWiFi,              //<! WiFi
    WKNetworkReachableViaOther              //<! 其他网络
};

/**
 *  阿里悟空链接状态
 */
typedef NS_ENUM(NSUInteger, WKSDKConnectStatus)
{
    WKSDKNoConnect = 0,     //<! 无链接
    WKSDKConnecting,        //<! 正在链接
    WKSDKConnectFail,       //<! 连接失败
    WKSDKConnected,         //<! 通道连接成功，非认证，只允许非认证接口通信
    WKSDKGrantedConnected   //<! 通道连接并认证成功！
};

FOUNDATION_EXTERN NSString *const WKNetworkStatusChangedNotification;//<! 阿里悟空网络状态变更通知
FOUNDATION_EXTERN NSString *const WKNetworkStatusUserInfoKey;//<! 阿里悟空网络状态，NSNumber<WKNetworkStatus>

FOUNDATION_EXTERN NSString *const WKSDKConnectStatusChangedNotification;//<! 阿里悟空SDK通道连接状态
FOUNDATION_EXTERN NSString *const WKSDKConnectStatusUserInfoKey;//<! 阿里悟空SDK通道连接状态，NSNumber<WKSDKConnectStatus>

FOUNDATION_EXTERN NSString *const WKReceiveIMVoipIncomeCallNotify;//<! voip 来电推送
FOUNDATION_EXTERN NSString *const WKReceiveIMVoipIncomeKey;//<! voip来电通知userInfo key NSData


/**
 *  阿里悟空IM开发环境定义
 */
typedef NS_ENUM(NSInteger, WKEnvironmentType)
{
    WKEnvironmentDistribution   = 0,    //!< 线上环境
    WKEnvironmentDaily          = 2,    //!< 日常环境
    WKEnvironmentPrerelease     = 3,    //!< 预发环境
};


/**
 * mediaId所用到的几种环境
 */
typedef NS_ENUM(NSInteger, MediaIdEnvironmentType)
{
    MediaIdEnvironmentDaily = 1,        //测试环境
};



/// 自动登录返回值状态
typedef NS_ENUM(NSUInteger, WKAutoLoginStatus) {
    WKAutoLoginOffline = 0,//<! 离线登录，实际上连接建立失败，
    WKAutoLoginOnline = 1,//<! 登录成功，连接成功建立
};


/**
 *  终端类型定义
 */
typedef NS_ENUM(NSInteger, WKDeviceType)
{
    /**
     * web
     */
    WKDeviceWebType        = 0,
    
    /**
     * app
     */
    WKDeviceAppType        = 1,
    
    /**
     * 全部类型
     */
    WKDeviceAllType        = 2,
    
};


@protocol IMError;


FOUNDATION_EXTERN NSString *const WKAuthTokenInvalidNotification;//!< token失效通知，收到此通知建议调用logout接口，你也可以选择重新login
FOUNDATION_EXTERN NSString *const WKAuthTokenInvalidReasonKey;//!< token失效原因key，值NSString类型
FOUNDATION_EXTERN NSString *const WKAuthLoginOKNotification;//!< login ok，用户相关的初始化可以放这里, lwp的认证可能还没完成
FOUNDATION_EXTERN NSString *const WKAuthLogoutOKNotification;//!< logout ok，用户相关的清理可以放这里
FOUNDATION_EXTERN NSString *const WKAuthTokenRefreshedNotification;//!< token refreshed，token刷新后


@protocol WKAuthProtocol;

@protocol WKAuthDelegate <NSObject>

@optional


- (void)loginSuccessWithAuthService:(id<WKAuthProtocol> )authService;

@end



/**
 *  阿里悟空IMSDK认证协议，要使用阿里悟空IMSDK的服务，如即时消息，语音视屏通话等，必须先通过平台认证接口登录
 */
@protocol WKAuthProtocol<NSObject>



/**
 *  注册用户接口，若注册成功后直接登录成功
 *
 *  @param openId     用户在domain下的唯一id，可以理解userId
 *  @param openSecret 对应用户的密钥不可逆hash值
 *  @param appKey     三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret  三方app在阿里悟空IM平台申请appKey的私钥对
 *  @param orgnizationId  企业id
 *  @param domain     企业业务表示，三方app在其企业的业务线
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey以及cmd，keys分别是@"domain",@"nickName",@"openId",@"cmd"
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)registerWithOpenId:(int64_t)openId
                             openSecret:(NSString *)openSecret
                                 appKey:(NSString *)appKey
                              appSecret:(NSString *)appSecret
                          orgnizationId:(NSString *)orgnizationId
                                 domain:(NSString *)domain
                           successBlock:(void (^)(NSDictionary *authInfo))successBlock
                           failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  认证请求。(如果此用户不存在，内部会注册此用户)
 *
 *  @param openId     用户在domain下的唯一id，可以理解userId
 *  @param openSecret 对应用户的密钥不可逆hash值
 *  @param appKey     三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret  三方app在阿里悟空IM平台申请appKey的私钥对
 *  @param orgnizationId  企业id
 *  @param domain     企业业务表示，三方app在其企业的业务线
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey以及cmd，keys分别是@"domain",@"nickName",@"openId",@"cmd"
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)loginWithOpenId:(int64_t)openId
                          openSecret:(NSString *)openSecret
                              appKey:(NSString *)appKey
                           appSecret:(NSString *)appSecret
                       orgnizationId:(NSString *)orgnizationId
                              domain:(NSString *)domain
                        successBlock:(void (^)(NSDictionary *authInfo))successBlock
                        failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  认证请求。
 *
 *  @param domain       domain组织域
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param secretToken  secretToken因子包含orgid,openid,opensecret,appkey,appsecret
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey以及cmd，keys分别是@"domain",@"nickName",@"openId",@"cmd"
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)loginWithDomain:(NSString *)domain
                              appKey:(NSString *)appkey
                         secretToken:(NSString *)secretToken
                        successBlock:(void (^)(NSDictionary *authInfo))successBlock
                        failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  认证请求。
 *
 *  @param domain       domain组织域
 *  @param appkey       appkey
 *  @param openId       openId
 *  @param nonce        随机数
 *  @param timestamp    时间戳
 *  @param signature    signature
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey以及cmd，keys分别是@"domain",@"nickName",@"openId",@"cmd"
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)loginWithDomain:(NSString *)domain
                              appKey:(NSString *)appkey
                              openId:(int64_t)openId
                               nonce:(NSString *)nonce
                           timestamp:(int64_t)timestamp
                           signature:(NSString *)signature
                        successBlock:(void (^)(NSDictionary *authInfo))successBlock
                        failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  请求验证码，将以短信的方式发送到指定的手机上
 *  @param org          org
 *  @param domain       domain组织域
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret    appSecret
 *  @param mobile       接收验证手机号码
 *  @param successBlock 发起成功后回调
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)requestSMSWithOrg:(NSString *)org
                                domain:(NSString *)domain
                                appKey:(NSString *)appKey
                             appSecret:(NSString *)appSecret
                              toMobile:(NSString *)mobile
                          successBlock:(void (^)(void))successBlock
                          failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  使用短信验证码登录
 *
 *  @param org          org
 *  @param domain       domain组织域
 *  @param appkey       三方app在阿里悟空IM平台申请的app唯一id
 *  @param appSecret    appSecret
 *  @param mobile       手机号码
 *  @param code         短信验证码
 *  @param successBlock 发起成功后回调
 *          @param authInfo中包含domain,nickName,openId,appKey,cmd以及user，
 *              keys:value分别是@"domain":NSString,@"nickName":NSString,@"openId":NSNumber<int64_t>,@"cmd":NSString,@"user":id<WKUserProtocol>
 *  @param failureBlock 发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)loginBySMSWithOrg:(NSString *)org
                                domain:(NSString *)domain
                                appKey:(NSString *)appKey
                             appSecret:(NSString *)appSecret
                                mobile:(NSString *)mobile
                                  code:(NSString *)code
                          successBlock:(void (^)(NSDictionary *authInfo))successBlock
                          failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  高级登陆接口
 *
 *  @param appKey           三方app在阿里悟空IM平台申请的app唯一id
 *  @param domain           企业业务表示，三方app在其企业的业务线
 *  @param openId           用户在domain下的唯一id，可以理解userId
 *  @param refreshToken     三方app从悟空服务器获取的refreshToken
 *  @param accessToken      三方app从悟空服务器获取的accessToken
 *  @param successBlock     发起成功后回调
 *          @param authInfo 包含domain,nickName,openId,appKey以及cmd，keys分别是@"domain",@"nickName",@"openId",@"cmd"
 *  @param failureBlock     发起失败后回调
 *
 *  @return 可用于取消请求的对象
 */
- (void)loginWithAppKey:(NSString *)appKey
                              domain:(NSString *)domain
                              openId:(int64_t)openId
                        refreshToken:(NSString *)refreshToken
                         accessToken:(NSString *)accessToken
                        successBlock:(void (^)(NSDictionary *authInfo))successBlock
                        failureBlock:(void (^)(id<IMError> error))failureBlock;

/**
 *  初始化阿里悟空IM平台，根据需要是否直接自动登录，比如上次已经登录某用户OpenId，当再次启动时可以直接免登
 *  如果发现token确实失效，平台会抛出WKAuthTokenInvalidNotification通知
 *  @param openId   你需要自动启动哪一个用户的OpenId 如果传入0表示用latestAuthInfo登录
 *  @param  needAutoLogin 是否需要自动登录，如果上次成功登录，传入YES，将自动启动阿里悟空IM，传入NO不会启动阿里悟空IM
 *  @param  completion 启动结果
 *      @param status 一个表示有网状态启动，一个是离线启动
 */
- (void)launchEngineWithOpenId:(int64_t)openId
                 needAutoLogin:(BOOL)needAutoLogin
                    completion:(void (^)(WKAutoLoginStatus status))completion;


/**
 *  登出接口，将释放所有资源
 *
 *  @param completion 注销完成回调
 *
 */
- (void)logoutWithCompletion:(void (^)(void))completion;


/**
 *  将终端踢下线接口(目前只支持踢web端下线)
 *  @param type             要踢出的终端类型
 *  @param message          提示消息
 *  @param successBlock     成功回调
 *  @param failureBlock     失败回调
 **/
- (void)kickDeviceWithClientType:(WKDeviceType)type
                         message:(NSString *)message
                    successBlock:(void (^)(void))successBlock
                    failureBlock:(void (^)(id<IMError> error))failureBlock;


/**
 *  注册各模块版本号，请在app启动后，用户登录或自动登录之前调用
 *  @param module   模块名称
 *  @param version  模块的版本号
 */
@optional
- (void)registerModule:(NSString *)module withVersion:(int)version;


/**
 *  获取各模块版本号
 */
@optional
- (NSString *)getModuleVersion;


/**
 *  最后一次成功登录的信息存储，包含domain,nickname,openId分别是@"domain",@"nickname",@"openId"
 *
 *  @return 最后一次成功登录的信息存储，包含domain,nickname,openId
 */
- (NSDictionary *)latestAuthInfo;


/**
 *  设置当前登录用户的nickname，请在登录成功后设置，否则可能无效
 *
 *  @param nickname 设置当前登录用户的nickname，用于apns推送。
 */
- (void)setNickname:(NSString *)nickname;

/**
 *  当前latestOpenId
 */
- (int64_t)latestOpenId;

/**
 *  当前latestScopeMD5
 */
- (NSString *)latestScopeMD5;

/**
 *  当前 currentOpenId
 */
- (int64_t)currentOpenId;

/**
 *  当前 currentScopeMD5
 */
- (NSString *)currentScopeMD5;

/**
 *  当前AppKey
 */
- (NSString *)getLWPAppKey;

/**
 *  当前AccessToken
 */
-( NSString *)accessToken;

/**
 *  当前DeviceID
 */
-( NSString *)deviceID;



#pragma mark 登录状态
/**
 *  判断是否已经登陆
 *
 *  @return 已经登陆返回YES；反之返回NO
 */
- (BOOL)isLogin;


+ (void)setEnvironment:(WKEnvironmentType)environment;


+ (WKEnvironmentType)environment;

/**
 *  业务UserAgent, "dingtalk:xxxxx" 格式由业务自定义，业务客户端服务端自协商，悟空仅提供一个通道，建立长连接之前设置有效。
 */

+(void)setBizUserAgent:(NSString *)bizUserAgent;


/**
 *  获取业务UserAgent
 */
+(NSString *)getBizUserAgent;


/**
 *  设置白名单
 */
-(void)setWhiteUrls:(NSArray *)urls;

/**
 *  启动lwp网络，在调用白名单中的函数前，需要先启动lwp, 因为在这个时间，im 不会自动启动lwp.
 *
 *  @param appKey 阿里悟空appKey
 */
-(void)startLWPWithAppKey:(NSString *)appKey;

/**
 *  设置lwp cache header
 *
 */
-(void)setCacheHeaders:(NSMutableDictionary *)cacheHeaders;

/**
 *  取lwp cache header
 *
 */
-(NSMutableDictionary *)getCacheHeaders;


/**
 *  获取user agent
 *
 */
+ (NSString *)getUserAgent;


@end
