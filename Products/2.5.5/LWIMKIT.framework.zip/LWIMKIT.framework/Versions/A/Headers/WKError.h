//
//  WKError.h
//  LWIMKitExample
//
//  Created by jiaruis on 14-6-10.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMError.h"

@interface WKError : NSObject<IMError>

+ (id<IMError>)defaultErrorWithDomain:(NSString *)domain
                                 code:(NSInteger)code
                               reason:(NSString *)reason
                             userInfo:(NSDictionary *)dict;

+ (id<IMError>)paramsErrorWithDomain:(NSString *)domain;

@end
