//
//  LWDatabase.h
//  LWDatabase
//
//  Created by 香象 on 25/11/13.
//  Copyright (c) 2013 香象. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

#if OS_OBJECT_USE_OBJC
#undef SDDispatchQueueRelease
#undef SDDispatchQueueSetterSementics
#define SDDispatchQueueRelease(q)
#define SDDispatchQueueSetterSementics strong
#else
#undef SDDispatchQueueRelease
#undef SDDispatchQueueSetterSementics
#define SDDispatchQueueRelease(q) (dispatch_release(q))
#define SDDispatchQueueSetterSementics assign
#endif

@class OpenDatabase;

@protocol OpenDatabaseDelegate<NSObject>
- (void)didOpenDatabase:(OpenDatabase *)database withDbPath:(NSString *)databasePath;
- (void)didCloseDatabase:(OpenDatabase *)database;
@end

@interface OpenDatabase : NSObject
@property (nonatomic, copy) NSString *
dbName; //给数据库一个名字，以便后期从搜索引擎中取出数据后能通过dbname来找到相应的db对象
@property (nonatomic, readonly) sqlite3 *database;
@property (nonatomic, weak) id<OpenDatabaseDelegate> delegate;

- (NSMutableArray *)calcRowsForStatement:(sqlite3_stmt *)statement rowClass:(Class)rowClass;

#pragma init method
- (id)initWithPath:(NSString *)filePath;
- (id)initWithFileName:(NSString *)fileName;

#pragma reopen other database
- (NSString *)pathToDatabase;
- (void)setPathToDatabase:(NSString *)pathToDatabase;

#pragma sync method
- (NSArray *)executeSql:(NSString *)sql
         withParameters:(NSArray *)parameters
        withClassForRow:(Class)rowClass;
- (NSArray *)executeSqlV2:(NSString *)sql
           withParameters:(NSArray *)parameters
          withClassForRow:(Class)rowClass
               rowChanged:(NSUInteger *)rowChanged;

- (NSArray *)executeSql:(NSString *)sql withParameters:(NSArray *)parameters;
- (NSArray *)executeSqlV2:(NSString *)sql
           withParameters:(NSArray *)parameters
               rowChanged:(NSUInteger *)rowChanged;

- (NSArray *)executeSql:(NSString *)sql;
- (NSArray *)executeSqlWithParameters:(NSString *)sql, ...;

#pragma async method
- (void)executeSql:(NSString *)sql
     withParameters:(NSArray *)parameters
    withClassForRow:(Class)rowClass
               done:(void (^)(NSArray *results))doneBlock;
- (void)executeSql:(NSString *)sql
    withParameters:(NSArray *)parameters
              done:(void (^)(NSArray *results))doneBlock;
- (void)executeSql:(NSString *)sql done:(void (^)(NSArray *results))doneBlock;

//这个是返回sql里的第一个数据，并且返回查询结果的个数
- (id)executeSql:(NSString *)sql
     withParameters:(NSArray *)parameters
    withClassForRow:(Class)rowClass
         totalFound:(int *)totalFound;

#pragma Transaction method
- (void)inTransaction:(void (^)(OpenDatabase *db, BOOL *rollback))block;
- (void)inTransaction:(void (^)(OpenDatabase *db, BOOL *rollback))block
                 done:(void (^)(bool isFinish))doneBlock;
- (int)fieldDataReturn:(NSString *)sql;

#pragma close database
- (void)close;

#pragma clean database cache
- (NSArray *)columnsFromCacheForTableName:(NSString *)tableName;
- (void)cleanColumnsCache;
- (void)removeColumnsCacheForTableName:(NSString *)tableName;

#pragma GCD Queue priority
- (void)setQueuePriority:(dispatch_queue_priority_t)priority;

#pragma Other method
- (NSArray *)columnsForTableName:(NSString *)tableName;
- (NSUInteger)lastInsertRowId;
- (NSUInteger)rowChanges;
- (NSArray *)tableNames;
- (NSArray *)tables;

@end
