//
//  WKNoticeHandlerProtocol.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-9-8.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  第三方app需要关心的推送
 */

////////////////消息和会话相关//////////////////
FOUNDATION_EXTERN NSString *const WKMessageReceivedNotify;   //<! 单条消息推送通知,userInfo{WKUserInfoMessageKey}
FOUNDATION_EXTERN NSString *const WKMessageTagUpdatedNotify; //<! 单条消息推送通知,userInfo{WKUserInfoMessagesKey:@[wkmessage,...]}
FOUNDATION_EXTERN NSString *const WKMessageStatusUpdatedNotify; //<! 消息状态变更通知,userInfo{WKUserInfoMessageKey:@[wkmessage,...]}
FOUNDATION_EXTERN NSString *const WKConversationUpdatedNotify; //<! 消息状态变更通知,userInfo{WKUserInfoConversationKey}
FOUNDATION_EXTERN NSString *const WKConversationSortUpdatedNotify; //<! 会话sort变更通知,userInfo{WKUserInfoConversationKey}

// 会话输入状态变更通知
//<! 对方在会话输入状态的变更通知，
// userInfo{WKConversationTypingStatusInfosKey : @[{WKConversationId : NSString,
//                                                  WKConversationTypingTypeKey : NSNumber<WKConversationTypingType>,
//                                                  WKConversationTypingCommandKey : NSNumber<WKConversationTypingCommand>}]}
FOUNDATION_EXTERN NSString *const WKConversationUpdateTypingStatusNotify;
FOUNDATION_EXTERN NSString *const WKConversationTypingStatusInfosKey;
FOUNDATION_EXTERN NSString *const WKConversationIdKey;
FOUNDATION_EXTERN NSString *const WKConversationTypingTypeKey;      // @see WKConversationTypingType
FOUNDATION_EXTERN NSString *const WKConversationTypingCommandKey;   // @see WKConversationTypingCommand

FOUNDATION_EXTERN NSString *const WKReceiveCustomerDataNotify; //<! notice topic收到业务push消息

FOUNDATION_EXTERN NSString *const WKMessagesIsReadNotify;   //<! 消息已读,userInfo{WKUserInfoMessagesKey}

////////////////断线重连//////////////////
FOUNDATION_EXTERN NSString *const WKReconnectedNotify;
FOUNDATION_EXPORT NSString *const WKReconnectedStartNotify;         //<! wk开始批量接收到消息
FOUNDATION_EXPORT NSString *const WKReconnectedEndNotify;            //<! wk完成批量接收消息，并且完成存入db等操作
FOUNDATION_EXPORT NSString *const WKReconnectedStartEndUserInfoKey;
FOUNDATION_EXPORT NSString *const WKReconnectedStartEndMsgIdKey;

FOUNDATION_EXTERN NSString *const WKUserInfoMessageKey;      //<! 消息WKBizMessage
FOUNDATION_EXTERN NSString *const WKUserInfoConversationKey; //<!  会话WKBizConversation
FOUNDATION_EXTERN NSString *const WKUserInfoMessagesKey;      //<! 消息NSArray<WKBizMessage>
FOUNDATION_EXTERN NSString *const WKUserInfoConversationsKey; //<!  会话NSArray<WKBizConversation>

////////////////用户自定义//////////////////
FOUNDATION_EXTERN NSString *const WKUserInfoCustomerDataKey; //<!  业务推送WKUserInfoCustomerDataKey


FOUNDATION_EXTERN NSString *const WKCloudSettingNotify;     //云设置更新通知, userInfo{WKCloudSettingArrayKey}
FOUNDATION_EXTERN NSString *const WKCloudSettingArrayKey;   //消息NSArray<WKCloudSetting>

////////////////用户资料模块//////////////////
FOUNDATION_EXTERN NSString *const WKUserUpdatedNotify; //<! 用户资料状态变更通知,userInfo{WKUserInfoProfileKey}
FOUNDATION_EXTERN NSString *const WKUserInfoProfileKey; //<!  用户资料状态
FOUNDATION_EXTERN NSString *const WKUserInfoOpenIdKey; //<!  用户资料状态

////////////////终端在线状态//////////////////
FOUNDATION_EXTERN NSString *const WKDeviceStatusNotify;   //<! 终端在线状态通知,userInfo{WKDeviceStatusInfoKey:@WKDeviceStatus}
FOUNDATION_EXTERN NSString *const WKDeviceStatusInfoKey;


/**
 *  消息topic
 */
FOUNDATION_EXTERN NSString *const WKReceiveSingleMessageTopic;      //<! 收到单条消息
FOUNDATION_EXTERN NSString *const WKReceiveMessageTagTopic;         //<! 收到消息tag变更
FOUNDATION_EXTERN NSString *const WKReceiveMessageStatusTopic;      //<! 收到消息状态变更
FOUNDATION_EXTERN NSString *const WKReceiveReconnectTopic;          //<! 断线重联
FOUNDATION_EXTERN NSString *const WKReceiveConversationUpdateTopic; //<! 会话变更，title，icon，member
FOUNDATION_EXTERN NSString *const WKReceiveMessagesIsReadTopic;     //<! 消息已读推送
FOUNDATION_EXTERN NSString *const WKReceiveTraceLogUploadTopic;     //<! 上传trace log
FOUNDATION_EXTERN NSString *const WKReceiveDeviceStatusTopic;       //<! 终端在线状态通知


////////////////同步协议//////////////////
FOUNDATION_EXTERN NSString *const WKSyncProtocolNotify;//<! 同步协议通知,userInfo{WKUserInfoSyncProtocolKey}
FOUNDATION_EXTERN NSString *const WKUserInfoSyncProtocolKey;


/**
 *  推送通知处理者协议，调用IMEngine的pushService服务来注册
 */
@protocol WKNoticeHandlerProtocol<NSObject>

@required

/**
 *  通知返回值类型
 */
- (Class)returnedValueClass;

/**
 *  成功收到推送通知
 */
- (void)pushReceived:(NSString *)messageId value:(id)value;

/**
 *  收到推送异常
 */
- (void)pushCaught:(NSString *)messageId error:(NSError *)error;

@end

/**
 *  消息推送特殊委托
 */
@protocol WKWessageReceivedNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  消息状态变更推送特殊委托
 */
@protocol WKWessageStatusUpdatedNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  重联推送处理
 */
@protocol WKReconnectNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end

/**
 *  消息已读推送通知
 */
@protocol WKMessageIsReadNoticeHandlerProtocol<WKNoticeHandlerProtocol, NSObject>

@optional
/**
 *  返回当前活跃的会话id列表 （一般只有一个数据，不排除你可以打开多个窗口）
 */
- (NSArray *)activeConversationIds; //

@end
