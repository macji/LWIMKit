//
//  LWFileResultValue.h
//  Laiwang
//
//  Created by guodi.ggd on 4/30/14.
//  Copyright (c) 2014 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LWPFileAttribute.h"

@interface LWPFileResultValue : NSObject<NSCopying, NSCoding>
@property (nonatomic, copy) NSString *originUrl;
@property (nonatomic, copy) NSString *thumbUrl;
@property (nonatomic, copy) NSString *hd;
@end

typedef LWPFileResultValue LWFileResultValue;


@interface LWPFileResultCaches : NSObject
- (void)saveFileResult:(LWPFileResultValue *)fileResult
              filePath:(NSString *)filePath
              fileData:(NSData *)fileData
              fileAttr:(LWPFileAttribute *)fileAttr;

- (LWPFileResultValue *)retrieveFileResult:(NSString *)filePath
                                  fileData:(NSData *)fileData
                                  fileAttr:(LWPFileAttribute *)fileAttr;

- (void)clearFileResultCacheIfNeeds;
@end