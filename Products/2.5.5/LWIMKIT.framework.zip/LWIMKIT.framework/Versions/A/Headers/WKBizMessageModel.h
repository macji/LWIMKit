//
//  WKBizMessageModel.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-10-16.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 *  消息变更通知
 */
FOUNDATION_EXTERN NSString *WKBizMessageDidChangedNotification;//<! 消息变更通知
FOUNDATION_EXTERN NSString *WKBizMessageUserInfoKey;//<! 对应WKBizMessage数据

/**
 *  消息业务类型
 */
typedef NS_ENUM(NSInteger, WKMessageType)
{
    /**
     *  普通消息,对应idl中contentmodeltype
     */
    WKMessageTypeNormal = 1,
    
    /**
     *  阅后即焚消息
     */
    WKMessageTypeSnap = 2,
    
    /**
     *  静默消息
     */
    WKMessageTypeQuiet = 3,
};

/**
 *  消息创建类型
 */
typedef NS_ENUM(NSInteger, WKMessageCreatorType)
{
    /**
     *  用户创建的消息
     */
    WKMessageCreatorTypeUser = 1,
    /**
     *  系统创建的消息，事实上很多时候都是用户模拟系统创建类型的，
     *  比如创建群聊时候显示的话，就是用户发起，但是表示为系统创建类型
     */
    WKMessageCreatorTypeSystem = 2 // 表示系统自动生成消息
};

/**
 *  消息的发送状态
 */
typedef NS_ENUM(NSUInteger, WKMessageSendStatus)
{
    /**
     *  发送失败
     */
    WKMessageSendStatusFailure = 1,
    /**
     *  发送中
     */
    WKMessageSendStatusSending = 2,
    /**
     *  发送成功
     */
    WKMessageSendStatusSuccess = 3,
};


/**
 *  聊天消息实例定义
 */
@protocol WKBizMessage <NSObject>

/**
 *  消息的本地ID，（用作服务端判重，APP端生成，以后将代替messageID,成为消息唯一ID）
 */
@property (nonatomic, copy, readonly) NSString *localMid;

/**
 *  消息的ID，发送给消息时这个值由业务方提供一个位置内容
 */
@property (nonatomic, assign, readonly) int64_t messageId;

/**
 *  消息所在会话的ID
 */
@property (nonatomic, copy, readonly) NSString *conversationId;

/**
 *  消息类型
 */
@property (nonatomic, readonly) WKMessageType messageType;

/**
 *  消息创建者类型，系统消息还是普通人消息
 */
@property (nonatomic) WKMessageCreatorType creatorType;

/**
 *  消息的创建时间，服务端时间(毫秒)
 */
@property (nonatomic) int64_t createdAt;

/**
 *  消息的未读人数
 */
@property (nonatomic) NSInteger unreadCount;

/**
 *  消息的所有接受者人数，含自己
 */
@property (nonatomic) long receiverCount;


/**
 *  仅仅针对接受者有意义，表示该消息是否已经已读，
 *  如果已读，这个消息看到的时候就不会往服务端发送读消息的指令
 */
@property (nonatomic) BOOL isRead;


/**
 *  发送者ID
 */
@property (nonatomic) int64_t senderId;


/**
 *  发送者版本
 */
@property (nonatomic) long senderTag;


/**
 *  DB标识消息的发送状态，已发送，发送中还是发送失败
 */
@property (nonatomic, readonly) WKMessageSendStatus sendStatus;


/**
 *  消息显示的内容，文本就是文本内容本身，图片就保存[图片]，语音就保存[语音]
 */
@property (nonatomic, copy) NSString *content;


/**
 * 消息附件类型, 可能存在多个附件类型，使用位运算表示
 */
@property (nonatomic) NSInteger attachmentsType;


/**
 *  消息附件的数组，可能有多个附件，里面保存对象应该为WKAttachment
 */
@property (nonatomic, strong) NSArray *attachments;


/**
 *  这个字段用于保存转发消息时，原始消息的消息ID
 */
@property (nonatomic, readonly) int64_t originalMessageId;

/**
 *  DB标识消息是否是自己发送的还是收到的
 */
@property (nonatomic, readonly) BOOL isMine;

/**
 *  业务方自定义的tag 消息本身一些特殊标记
 *
 */
@property (nonatomic, assign) NSInteger tag;

/**
 *  消息的其他附加信息（作用于消息本身，表示与所有接受者相关）//key-value只支持NSString
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *extension;

/**
 *  业务方自定义的bizTag 区别于tag，这条消息针针对此接收方或发送方而言的一些特殊标记
 *
 */
@property (nonatomic, assign) NSInteger privateTag;

/**
 *  消息的其他附加信息（作用于当前接受者或者发送者相关的配置）//key-value只支持NSString
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *privateExtension;

/**
 *  @某某某 列表，要求放入Key:NSNumber<openId>==>Value:NSString<nickname>
 */
@property (nonatomic, strong, readonly) NSMutableDictionary *atList;

/**
 *  添加 @某某某
 *  你也可以直接调用atList操作，如：
        [self.atList setObject:nickname forKey:@(openId)];
 *  @param openId 需要@某人的id
 *  @param nickname 需要@某人的昵称
 */
- (void)addAtOpenId:(int64_t)openId nickname:(NSString *)nickname;

/**
 *  移除 @某某某
 *  你也可以直接调用atList操作，如：
        [self.atList removeObjectForKey:@(openId)];
 *  @param openId 需要移除@某人的id
 */
- (void)removeAtOpenId:(int64_t)openId;

/**
 *  此条消息是否有@其他人
 *  你也可以直接调用atList操作，如：
        [self.atList count] > 0;
 *  @return 返回YES表示有@其他人，返回NO表示没有
 */
- (BOOL)hasAtSomeone;


/**
 *  此条消息是否有@其他人
 *  你也可以直接调用atList操作，如：
        nil != [self.atList objectForKey:@(openId)];
 *  @param openId @某人的id
 *  @return 返回YES表示有@此人，返回NO表示没有
 */
- (BOOL)hasAtOpenId:(int64_t)openId;


@end

