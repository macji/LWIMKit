//
//  IMEngine.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-8-19.
//  Copyright (c) 2014年 Alibaba. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "OpenDatabase.h"
#import "LWSQLiteContext.h"
#import "WKAuthProtocol.h"
#import "WKMessageServiceProtocol.h"
#import "WKConversationServiceProtocol.h"
#import "WKPushServiceProtocol.h"
#import "WKAPNSServiceProtocol.h"
#import "WKProfileServiceProtocol.h"
#import "WKCloudSettingServiceProtocol.h"
#import "WKUserProtocol.h"
#import "WKBizMessageBuilder.h"
#import "WKCloudSettingServiceProtocol.h"
#import "WKError.h"
#import "WKErrorCode.h"
#import "WKMember.h"
#import "WKMessageReceiverModel.h"
#import "WKNoticeHandlerProtocol.h"



/**
 *  IMEngine是集成所有服务的引擎
 */
@interface IMEngine : NSObject<WKAuthProtocol>

/** 
 *  设置SDK环境
 *  早于sharedIMEngine方法调用才会生效
 */
+ (void)setEnvironment:(WKEnvironmentType)environment;

/**
 *  获取当前SDK环境
 *
 *  @return 当前SDK环境
 */
+ (WKEnvironmentType)environment;

/**
 *  IMEngine单例
 */
+ (instancetype)sharedIMEngine;


#pragma mark IM Service

/**
 *  业务UserAgent, "dingtalk:xxxxx" 格式由业务自定义，业务客户端服务端自协商，悟空仅提供一个通道，建立长连接之前设置有效。
 */

+(void)setBizUserAgent:(NSString *)bizUserAgent;

/**
 *  会话列表相关service实现
 */
@property (nonatomic, strong, readonly) id<WKConversationServiceProtocol> conversationService;

/**
 *  消息发送相关service实现
 */
@property (nonatomic, strong, readonly) id<WKMessageServiceProtocol> messageService;

/**
 *  个人资料相关service实现
 */
@property (nonatomic, strong, readonly) id<WKProfileServiceProtocol> profileService;

/**
 *  云设置相关service实现
 */
@property (nonatomic, strong, readonly) id<WKCloudSettingServiceProtocol> cloudSettingService;


/**
 *  APNS推送服务接口
 */
@property (nonatomic, strong, readonly) id<WKAPNSServiceProtocol> apnsService;

/**
 *  服务器消息推送service实现
 */
@property (nonatomic, strong, readonly) id<WKPushServiceProtocol> pushService;

/*
 * 设置项：是否启用本SDK的profile模块
 */
- (void)setProfileModuleEnabled:(BOOL) enable;

/**
 *  其他配置接口
 */
- (void)setDatabasePicker:(OpenDatabase * (^)(NSString *scope))databasePicker;


/**
 *  版本号 格式如：1.0.0
 */
- (NSString *)versionString;

/**
 *  最近登录的用户openid
 */
- (int64_t)latestOpenId;//最后一次登录用户的uid

/**
 *  最近登录的用户md5
 */
- (NSString *)latestScopeMD5;//最后一次登录用户的 uid + "@" + domain 的MD5，保证域唯一性

/**
 *  最近登录的用户信息
 */
- (id<WKUserProtocol>)latestUserProfile;

/**
 *  获取当前的AppKey
 */
- (NSString *)getLWPAppKey;

/**
 *  启动lwp网络，在调用白名单中的函数前，需要先启动lwp, 因为在这个时间，im 不会自动启动lwp.
 *
 *  @param appKey 阿里悟空appKey
 */
- (void)startLWPWithAppKey:(NSString *)appKey;

@end
