//
//  IMError.h
//  LWSQLiteHookExample
//
//  Created by 云信 on 14-7-10.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol IMError <NSObject>

@property (nonatomic, readonly) NSUInteger code;
@property (nonatomic, strong, readonly) NSString *domain;
@property (nonatomic, strong, readonly) NSString *descriptions;

@property (nonatomic, strong, readonly) NSDictionary *userInfo;

@end
