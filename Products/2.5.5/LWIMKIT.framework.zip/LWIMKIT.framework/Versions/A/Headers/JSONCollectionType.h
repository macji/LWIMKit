//
//  JSONCollectionType.h
//  OCJSON
//
//  Created by zhiwen.mizw on 8/17/14.
//  Copyright (c) 2014 zhiwen.mizw. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JSONCollectionType<NSObject>

@optional
/**
 *  NSArray 集合里所存放类型
 *
 *  @param fieldName 属性名称
 *
 *  @return Array 集合中的元素类型
 */
- (Class)arrayElementTypeForFieldName:(NSString *)fieldName;

/**
 *  NSSet 集合里所存放的类型
 *
 *  @param fieldName 属性名称
 *
 *  @return Set集合中的元素类型
 */
- (Class)setElementTypeForFieldName:(NSString *)fieldName;

/**
 *  字典 指定Value 的对象是什么类型
 *
 *  @param fieldName 属性名称
 *
 *  @return 字典中，值元素的类型
 */
- (Class)dictionaryValueTypeForFieldName:(NSString *)fieldName;

/**
 *  id, id<xxxClass> 类型指定
 *
 *  @param fieldName 属性名称
 *
 *  @return id所表示的类型
 */
- (Class)idValueTypeForFieldName:(NSString *)fieldName;

@end
