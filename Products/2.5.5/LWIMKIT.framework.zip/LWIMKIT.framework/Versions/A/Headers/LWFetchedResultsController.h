//
//  LWFetchedResultsController.h
//  SQLiteHookDemo
//
//  Created by Lings on 14-6-4.
//  Copyright (c) 2014年 Alibaba(China)Technology Co.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LWSQLiteContext.h"
#import "LWFetchRequest.h"

@protocol LWFetchedResultsControllerDelegate;

@interface LWFetchedResultsController : NSObject

@property (nonatomic, strong, readonly) LWFetchRequest * fetchRequest;
@property (nonatomic, strong, readonly) LWSQLiteContext * sqliteContext;

@property (nonatomic, strong, readonly) NSArray * fetchedObjects;

@property (nonatomic, weak) id<LWFetchedResultsControllerDelegate> delegate;


- (id)initWithFetchRequest:(LWFetchRequest *)fetchRequest sqliteContext: (LWSQLiteContext *)context;


/**
 *  获取DB数据（size为fetchRequest.fetchLimit。fetchLimit为0表示拉取所有符合条件的数据）
 *
 *  @param error 如果获取失败，包含错误信息
 *
 *  @return 如果获取失败，返回NO，错误信息存放在error参数中
 */
- (BOOL)performFetch:(NSError **)error;


/**
 *  从当前已经获取到数据的位置获取更多DB数据。<br/>
 *  （size为fetchRequest.fetchLimit减去当前已有的数据数目。fetchLimit为0表示拉取`剩余`所有符合条件的数据）
 *
 *  @param error  如果获取失败，包含错误信息
 *
 *  @return 如果获取失败，返回NO，错误信息存放在error参数中
 */
- (BOOL)performFetchFromCurrentPosition:(NSError **)error;

/**
 *  停止监听数据变更，当前已经获取到的数据不会变化
 *
 *  @param error 如果停止失败，包含错误信息
 *
 *  @return 如果停止失败，返回NO，错误信息存放在error参数中
 */
- (BOOL)stopFetch:(NSError **)error;

@end


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

@protocol LWFetchedResultsControllerDelegate <NSObject>

typedef NS_ENUM(NSInteger, LWFetchedResultsChangeType) {

    LWFetchedResultsChangeInsert = 1,
	LWFetchedResultsChangeDelete = 2,
	LWFetchedResultsChangeMove = 3,
	LWFetchedResultsChangeUpdate = 4,
};

@optional

- (void)controllerWillChangeContent:(LWFetchedResultsController *)controller;

- (void)controller:(LWFetchedResultsController *)controller didChangeObject:(id)anObject atIndex:(NSUInteger)index forChangeType:(LWFetchedResultsChangeType)type newIndex:(NSUInteger)newIndex;

- (void)controllerDidChangeContent:(LWFetchedResultsController *)controller;

- (void)controllerDidRollback:(LWFetchedResultsController *)controller;

@end