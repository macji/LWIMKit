//
//  WKOAuthServiceFactory.h
//  LWIMKitExample
//
//  Created by lingminjun on 14-8-19.
//  Copyright (c) 2014年 香象. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WKAuthProtocol.h"

@interface WKAuthServiceFactory : NSObject

+ (id<WKAuthProtocol>)shareOAuthService; //返回一个新的实例

@end
